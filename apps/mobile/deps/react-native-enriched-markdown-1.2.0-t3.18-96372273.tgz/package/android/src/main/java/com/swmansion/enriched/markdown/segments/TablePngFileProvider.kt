package com.swmansion.enriched.markdown.segments

import androidx.core.content.FileProvider

// A distinct provider class keeps its manifest entry separate from the host's providers.
class TablePngFileProvider : FileProvider()
