import type { ProcessedColorValue } from 'react-native';
import type { StreamingAnimation } from './types/MarkdownTextProps';
/** `streamingConfig.animation` as the native views take it. */
export interface NormalizedStreamingEffects {
    animation: string;
    animationDuration: number;
    animationLength: number;
    animationStartColor: ProcessedColorValue | null | undefined;
    animationEndColor: ProcessedColorValue | null | undefined;
}
export declare function normalizeStreamingEffects(animation: StreamingAnimation | undefined): NormalizedStreamingEffects;
/**
 * normalizeStreamingEffects, kept while the options are the same: processColor makes a new object
 * for a PlatformColor each call, and the animation object itself is often new each render.
 */
export declare function useStreamingEffects(animation: StreamingAnimation | undefined): NormalizedStreamingEffects;
//# sourceMappingURL=streamingEffects.d.ts.map