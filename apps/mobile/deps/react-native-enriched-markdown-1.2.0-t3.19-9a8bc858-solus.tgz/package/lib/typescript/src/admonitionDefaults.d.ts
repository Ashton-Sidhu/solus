import type { AdmonitionsStyle } from './types/MarkdownStyle';
import type { AdmonitionTitles, AdmonitionType } from './types/admonitionTitles';
export type { AdmonitionType };
export declare const ADMONITION_TYPES: readonly ["note", "tip", "important", "warning", "caution"];
export declare const DEFAULT_ADMONITION_TITLES: Readonly<Record<AdmonitionType, string>>;
export interface ResolvedAdmonitionColors {
    color: string;
    backgroundColor: string;
}
export type ResolvedAdmonitions = Record<AdmonitionType, ResolvedAdmonitionColors>;
export declare function resolveAdmonitionColors(user: AdmonitionsStyle | undefined): ResolvedAdmonitions;
export type ResolvedAdmonitionTitles = Readonly<Record<AdmonitionType, string>>;
export declare function useAdmonitionTitles(titles: AdmonitionTitles | undefined): ResolvedAdmonitionTitles;
//# sourceMappingURL=admonitionDefaults.d.ts.map