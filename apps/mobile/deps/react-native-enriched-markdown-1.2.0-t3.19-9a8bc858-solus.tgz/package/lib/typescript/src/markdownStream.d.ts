import type { Spec } from './NativeEnrichedMarkdownParser';
/**
 * Markdown arriving in pieces (an LLM answer), shown by passing it to
 * `EnrichedMarkdownText` as `stream`. Appending re-renders nothing: only the
 * views showing the stream update, about every other frame. Create it outside React
 * (for example next to the message in your store), so it outlives the views.
 */
export interface MarkdownStream {
    /** Adds `chunk` to the end of the text. Ignored after `end()` or `dispose()`, with a warning in development. */
    append(chunk: string): void;
    /** The text appended so far; empty after `dispose()`, even while a view still shows it. */
    getText(): string;
    /** Marks the text complete: views showing it stop streaming and render it in full. */
    end(): void;
    /** Replaces the text (empty by default) and streams again, also after `dispose()`. */
    reset(text?: string): void;
    /**
     * Ends the stream, if `end()` wasn't called, and frees the text once no view
     * shows it. A view that mounts once it is freed shows nothing. A stream JS
     * no longer references is freed too, where the engine supports
     * FinalizationRegistry.
     */
    dispose(): void;
}
/** The stream as of the last frame. */
export interface MarkdownStreamSnapshot {
    /** The native stream holding the text; 0 without the native module. */
    readonly streamId: number;
    /** The native stream's length in bytes. */
    readonly length: number;
    /** The text itself, without the native module (web, Jest). */
    readonly text: string;
    readonly ended: boolean;
}
type NativeStreams = Pick<Spec, 'createStream' | 'appendToStream' | 'readStream' | 'disposeStream'>;
export declare function setNativeMarkdownStreams(module: NativeStreams | null | undefined): void;
export declare function createMarkdownStream(text?: string): MarkdownStream;
/** Whether `stream` has ended (null without one): re-renders when that changes, not on each frame. */
export declare function useMarkdownStreamEnded(stream: MarkdownStream | undefined): boolean | null;
/**
 * The stream as of the last frame, re-rendering on each new frame; null without a stream.
 * Every view reads it here, so this warns of an invalid one.
 */
export declare function useMarkdownStreamSnapshot(stream: MarkdownStream | undefined): MarkdownStreamSnapshot | null;
export {};
//# sourceMappingURL=markdownStream.d.ts.map