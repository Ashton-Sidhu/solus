package com.swmansion.enriched.markdown

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.Spannable
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils.TruncateAt
import android.util.Log
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.uimanager.PixelUtil
import com.facebook.yoga.YogaMeasureMode
import com.facebook.yoga.YogaMeasureOutput
import com.swmansion.enriched.markdown.parser.Md4cFlags
import com.swmansion.enriched.markdown.parser.Parser
import com.swmansion.enriched.markdown.renderer.Renderer
import com.swmansion.enriched.markdown.segments.BlockSlotMeasurer
import com.swmansion.enriched.markdown.segments.BlockSlotSegmentView
import com.swmansion.enriched.markdown.segments.BlockquoteContainerView
import com.swmansion.enriched.markdown.segments.CodeBlockContainerView
import com.swmansion.enriched.markdown.segments.MarkdownSegmentRenderer
import com.swmansion.enriched.markdown.segments.RenderedSegment
import com.swmansion.enriched.markdown.segments.SegmentHeightMeasurer
import com.swmansion.enriched.markdown.segments.TableContainerView
import com.swmansion.enriched.markdown.segments.splitASTIntoSegments
import com.swmansion.enriched.markdown.spans.ImageSpan
import com.swmansion.enriched.markdown.spans.LinkPillSpan
import com.swmansion.enriched.markdown.spans.MarginBottomSpan
import com.swmansion.enriched.markdown.spans.MathMeasureRequest
import com.swmansion.enriched.markdown.spans.MathMetrics
import com.swmansion.enriched.markdown.spans.MathRenderMode
import com.swmansion.enriched.markdown.styles.LinkPillContent
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.BoundsForWidthUtils
import com.swmansion.enriched.markdown.utils.common.BreakStrategyUtils
import com.swmansion.enriched.markdown.utils.common.CodeBlockStreamingMode
import com.swmansion.enriched.markdown.utils.common.EllipsizeUtils
import com.swmansion.enriched.markdown.utils.common.FeatureFlags
import com.swmansion.enriched.markdown.utils.common.LinkRegexConfig
import com.swmansion.enriched.markdown.utils.common.MediaStreamingMode
import com.swmansion.enriched.markdown.utils.common.SlotLayoutReuse
import com.swmansion.enriched.markdown.utils.common.StreamingFilterResult
import com.swmansion.enriched.markdown.utils.common.StreamingMarkdownFilter
import com.swmansion.enriched.markdown.utils.common.TableStreamingMode
import com.swmansion.enriched.markdown.utils.common.layout.isLayoutRTL
import com.swmansion.enriched.markdown.utils.text.extensions.replaceMathSpansWithPlaceholders
import com.swmansion.enriched.markdown.utils.text.span.prepareWidthAwareSpans
import com.swmansion.enriched.markdown.utils.text.view.inViewSpanOrder
import com.swmansion.enriched.markdown.utils.text.view.isAdoptedText
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.ceil

/**
 * Manages text measurements for ShadowNode layout.
 * Parses and renders markdown to Spannable at measure time for accurate height calculation.
 */
object MeasurementStore {
  private const val TAG = "MeasurementStore"

  // Rounding between the view's dp size and the walk's px frames.
  private const val SLOT_TOLERANCE_PX = 1.5f

  internal data class PaintParams(
    val typeface: Typeface,
    val fontSize: Float,
  )

  internal data class MeasurementParams(
    val cachedWidth: Float,
    val cachedSize: Long,
    val spannable: CharSequence?,
    val paintParams: PaintParams,
    val markdownHash: Int,
  )

  internal val data = ConcurrentHashMap<Int, MeasurementParams>()

  // Store font scaling settings per view ID
  private data class FontScalingSettings(
    val allowFontScaling: Boolean = true,
    val maxFontSizeMultiplier: Float = 0f,
  )

  private val fontScalingSettings = ConcurrentHashMap<Int, FontScalingSettings>()

  private val breakStrategies = ConcurrentHashMap<Int, String>()

  // The measure path and the display TextView resolve the same clamp. 0 means unlimited.
  private val numberOfLinesByViewId = ConcurrentHashMap<Int, Int>()

  private val ellipsizeModeByViewId = ConcurrentHashMap<Int, String>()

  // Code blocks the user wrapped, by document-order index across nesting (see CodeBlockWrapState).
  private val wrappedCodeBlocks = ConcurrentHashMap<Int, Set<Int>>()

  // The content size each view last laid its rendered markdown out at, and what each
  // view's last measurement saw: a stream's next update takes the first instead of
  // measuring the whole document again (laidOutSizeForStreamUpdate).
  private data class LaidOutSize(
    val widthPx: Float,
    val size: Long,
    val markdown: String,
    val slots: List<SlotLayoutReuse.ShownSlot> = emptyList(),
    // Laid out as at any wider width (laysOutAtAnyWiderWidth): a view hugging its content.
    val fitsWiderWidths: Boolean = false,
  ) {
    fun isFor(width: Float) = abs(widthPx - width) < 1f || (fitsWiderWidths && width > widthPx)
  }

  // A slot child's frame as the walk placed it, px within the host's content box.
  private data class SlotFrame(
    val id: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
  )

  // The last full measurement of a streamed document with block slots, for the next update to
  // take the view's height instead (slotStreamUpdate).
  private data class SlotMeasured(
    val markdown: String,
    val layoutKey: StreamLayoutKey,
    val slotIds: List<String>,
    val widthPx: Float,
    val heightPx: Float,
    val size: Long,
    val frames: List<SlotFrame>,
  )

  private val slotMeasurements = ConcurrentHashMap<Int, SlotMeasured>()

  // The frames the walk of the current full measurement places, in document order.
  private val recordedFrames = ThreadLocal<MutableList<SlotFrame>?>()

  // Everything besides the markdown and the width that a streamed document's layout depends on,
  // compared whole: a hash of it could collide.
  private data class StreamLayoutKey(
    // The layout props (MeasureConfig.key).
    val config: Int,
    val fontScale: Float,
    val allowFontScaling: Boolean,
    val maxFontSizeMultiplier: Float,
    val splitTableSegments: Boolean,
    val wrappedCodeBlocks: Set<Int>?,
    val breakStrategy: String?,
    val density: Float,
    val rtl: Boolean,
  )

  private data class MeasuredInputs(
    val markdown: String,
    val layoutKey: StreamLayoutKey,
    val widthPx: Float,
    // What the measurement returned, filled in once known.
    val size: Long? = null,
    // Whether that was the size the view laid out, which may be behind the markdown.
    val fromLaidOut: Boolean = false,
  )

  private val laidOutSizes = ConcurrentHashMap<Int, LaidOutSize>()

  // For each line of the text a view laid out itself at [widthPx], the widest line up to it
  // ([storeLaidOut]).
  private class LaidOutLines(
    val widthPx: Int,
    val widths: FloatArray,
  )

  private val laidOutLines = ConcurrentHashMap<Int, LaidOutLines>()

  // At each view's last two widths, the latest first: Yoga can measure a node twice a pass (its
  // flex basis, then the width it shrinks to).
  private val previousInputs = ConcurrentHashMap<Int, List<MeasuredInputs>>()

  // Each view's last measurement, a shortcut's too: the width the view lays out at, and the size
  // its own layout is compared with.
  private data class Measured(
    val widthPx: Float,
    val size: Long,
  )

  private val lastMeasured = ConcurrentHashMap<Int, Measured>()

  private fun resolveFontScalingSettings(
    viewId: Int?,
    config: MeasureConfig,
  ): FontScalingSettings {
    val stored = viewId?.let { fontScalingSettings[it] }
    return FontScalingSettings(
      allowFontScaling = config.allowFontScaling ?: stored?.allowFontScaling ?: true,
      maxFontSizeMultiplier = config.maxFontSizeMultiplier ?: stored?.maxFontSizeMultiplier ?: 0f,
    )
  }

  // TextView paints with ANTI_ALIAS_FLAG. On older Android a bare TextPaint lacks it, and the
  // glyph hinting that differs between the two moves text widths by a few pixels.
  private val measurePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
  private val measureRenderer = Renderer()

  // Measures a slot child through the GFM shadow node's current measure session
  // (BlockSlotMeasureSession); px in, px out, 0 outside a measurement.
  @JvmStatic
  private external fun nativeMeasureBlockSlot(
    slotId: String,
    x: Float,
    y: Float,
    width: Float,
  ): Float

  @JvmStatic
  private external fun nativeDiscardBlockSlotFrames()

  // The markdown and layout config the shadow node measures with (MarkdownMeasureSession): pulled
  // only when Kotlin doesn't have them, since the markdown is a long string to cross over and the
  // config a map to parse.
  @JvmStatic
  private external fun nativeMeasureMarkdown(): String?

  @JvmStatic
  private external fun nativeMeasureConfig(): ReadableMap?

  // Keys the shadow node sends instead of the props: one per distinct layout config and one per
  // distinct markdown (MarkdownMeasureSession.h).
  private const val CONFIG_KEY = "configKey"
  private const val TEXT_KEY = "textKey"

  // Parsed configs by key; messages with the same style and content props share one. The bound is
  // against an app that makes new ones on every render; clearing only costs parsing them again.
  private const val MAX_CONFIGS = 256
  private val configs = ConcurrentHashMap<Int, MeasureConfig>()

  private class MeasuredMarkdown(
    val key: Int,
    val markdown: String,
  )

  // Each view's last markdown: Yoga measures twice per update with the same props.
  private val measuredMarkdown = ConcurrentHashMap<Int, MeasuredMarkdown>()

  private fun measureInput(
    id: Int?,
    props: ReadableMap?,
  ): MeasureInput {
    if (props == null || !props.hasKey(CONFIG_KEY)) {
      Log.w(TAG, "Measured without the shadow node's keys; measuring nothing")
      return MeasureInput("", MeasureConfig(0, null))
    }
    return MeasureInput(markdownFor(id, props.getInt(TEXT_KEY)), configFor(props.getInt(CONFIG_KEY)))
  }

  private fun configFor(key: Int): MeasureConfig {
    configs[key]?.let { return it }
    // No session means no measurement to take the config from; parse nothing into the cache.
    val map = nativeMeasureConfig() ?: return MeasureConfig(key, null).also { Log.w(TAG, "No layout config to measure with") }
    val config = MeasureConfig(key, map)
    if (configs.size >= MAX_CONFIGS) configs.clear()
    configs[key] = config
    return config
  }

  private fun markdownFor(
    id: Int?,
    key: Int,
  ): String {
    val kept = id?.let { measuredMarkdown[it] }
    if (kept != null && kept.key == key) return kept.markdown
    // No session means no measurement to take the markdown from; keep nothing.
    val markdown = nativeMeasureMarkdown() ?: return "".also { Log.w(TAG, "No markdown to measure") }
    if (id != null) measuredMarkdown[id] = MeasuredMarkdown(key, markdown)
    return markdown
  }

  private val slotMeasurer =
    object : BlockSlotMeasurer {
      override fun measure(
        slotId: String,
        xPx: Float,
        yPx: Float,
        widthPx: Float,
      ) = nativeMeasureBlockSlot(slotId, xPx, yPx, widthPx).also { heightPx ->
        recordedFrames.get()?.let { frames ->
          frames.removeAll { it.id == slotId }
          frames.add(SlotFrame(slotId, xPx, yPx, widthPx, heightPx))
        }
      }

      override fun discard() {
        recordedFrames.get()?.clear()
        nativeDiscardBlockSlotFrames()
      }
    }

  @Volatile
  private var lastKnownFontScale: Float = 1.0f

  /** Updates measurement with rendered Spannable. Returns true if height changed. */
  fun store(
    id: Int,
    spannable: CharSequence?,
    paint: TextPaint,
    trailingMarginBottomPx: Float = 0f,
    renderedMarkdown: String = "",
  ): Boolean {
    val cached = data[id]
    val last = lastMeasured[id]
    val width = last?.widthPx ?: cached?.cachedWidth ?: 0f
    val oldSize = last?.size ?: cached?.cachedSize ?: 0L
    val existingHash = cached?.markdownHash ?: 0
    val paintParams = PaintParams(paint.typeface ?: Typeface.DEFAULT, paint.textSize)

    var newSize = measure(width, spannable, paint, id)
    // A view's adopted buffer changes in place as patches land, on the main thread: a later
    // measurement at another width renders the markdown again instead of laying it out.
    val keptText = spannable.takeUnless { isAdoptedText(it) }
    if (trailingMarginBottomPx > 0f) {
      newSize =
        YogaMeasureOutput.make(
          YogaMeasureOutput.getWidth(newSize),
          YogaMeasureOutput.getHeight(newSize) + PixelUtil.toDIPFromPixel(trailingMarginBottomPx),
        )
    }
    data[id] = MeasurementParams(width, newSize, keptText, paintParams, existingHash)
    // Only if no measurement at another width landed meanwhile.
    if (last != null) lastMeasured.replace(id, last, Measured(width, newSize))
    laidOutLines.remove(id)
    // Without the width the last measurement offered, the size isn't laid out for
    // it: the next measurement goes the full way and brings the width back.
    if (width > 0f) laidOutSizes[id] = LaidOutSize(width, newSize, renderedMarkdown) else laidOutSizes.remove(id)
    return oldSize != newSize
  }

  /**
   * [store] from the view's own [layout], measuring only the lines from [changedFrom] on. Null
   * when [layout] isn't the one the measurement would build (another width, or a line limit).
   */
  fun storeLaidOut(
    id: Int,
    layout: Layout,
    changedFrom: Int,
    trailingMarginBottomPx: Float,
    renderedMarkdown: String,
  ): Boolean? {
    val cached = data[id] ?: return null
    val last = lastMeasured[id]
    val width = last?.widthPx ?: cached.cachedWidth
    if (width <= 0f || resolveMaxLines(id) > 0) return null
    val measuredLayoutWidth = ceil(width).toInt().coerceAtLeast(1)
    val hugs = layout.width < measuredLayoutWidth && laysOutAtAnyWiderWidth(layout)
    if (layout.width != measuredLayoutWidth && !hugs) return null

    val lineCount = layout.lineCount
    val previousWidths = laidOutLines[id]?.takeIf { it.widthPx == layout.width }?.widths
    val kept =
      if (previousWidths == null ||
        changedFrom <= 0
      ) {
        0
      } else {
        minOf(layout.getLineForOffset(changedFrom), previousWidths.size, lineCount)
      }
    val widths = FloatArray(lineCount)
    previousWidths?.copyInto(widths, 0, 0, kept)
    for (line in kept until lineCount) {
      widths[line] = maxOf(if (line > 0) widths[line - 1] else 0f, layout.getLineWidth(line))
    }
    laidOutLines[id] = LaidOutLines(layout.width, widths)

    val height = if (lineCount > 0) layout.getLineBottom(lineCount - 1).toFloat() else 0f
    val newSize =
      YogaMeasureOutput.make(
        PixelUtil.toDIPFromPixel(ceil(widths.lastOrNull() ?: 0f)),
        PixelUtil.toDIPFromPixel(height) + PixelUtil.toDIPFromPixel(trailingMarginBottomPx),
      )
    data[id] = cached.copy(cachedWidth = width, cachedSize = newSize, spannable = null)
    if (last != null) lastMeasured.replace(id, last, Measured(width, newSize))
    laidOutSizes[id] =
      if (hugs) {
        LaidOutSize(layout.width.toFloat(), newSize, renderedMarkdown, fitsWiderWidths = true)
      } else {
        LaidOutSize(width, newSize, renderedMarkdown)
      }
    return (last?.size ?: cached.cachedSize) != newSize
  }

  /**
   * Whether [layout] lays its text out as any wider layout would: no line wraps for the width and
   * nothing in it is sized to the width.
   */
  internal fun laysOutAtAnyWiderWidth(layout: Layout): Boolean {
    val text = layout.text
    for (line in 0 until layout.lineCount - 1) {
      val end = layout.getLineEnd(line)
      if (end <= 0 || text[end - 1] != '\n') return false
    }
    val spanned = text as? Spanned ?: return true
    return spanned.getSpans(0, spanned.length, ImageSpan::class.java).isEmpty() &&
      spanned.getSpans(0, spanned.length, LinkPillSpan::class.java).isEmpty()
  }

  /** The content size [id]'s view laid out [markdown] at, laid out for [widthPx]. */
  internal fun storeLaidOutSize(
    id: Int,
    widthPx: Float,
    size: Long,
    markdown: String,
    slots: List<SlotLayoutReuse.ShownSlot> = emptyList(),
    fitsWiderWidths: Boolean = false,
  ) {
    laidOutSizes[id] = LaidOutSize(widthPx, size, markdown, slots, fitsWiderWidths)
  }

  fun clearLaidOutSize(id: Int) {
    laidOutSizes.remove(id)
  }

  fun release(id: Int) {
    data.remove(id)
    laidOutSizes.remove(id)
    laidOutLines.remove(id)
    previousInputs.remove(id)
    lastMeasured.remove(id)
    slotMeasurements.remove(id)
    measuredMarkdown.remove(id)
    breakStrategies.remove(id)
    numberOfLinesByViewId.remove(id)
    ellipsizeModeByViewId.remove(id)
    wrappedCodeBlocks.remove(id)
  }

  fun updateWrappedCodeBlocks(
    viewId: Int,
    indices: Set<Int>,
  ) {
    if (indices.isEmpty()) wrappedCodeBlocks.remove(viewId) else wrappedCodeBlocks[viewId] = indices
    data.remove(viewId)
  }

  fun invalidate(id: Int) {
    data.remove(id)
    lastMeasured.remove(id)
  }

  // Content-box width (px) the measure pass last wrapped at; the display view insets to match (#805).
  fun contentBoxWidthPx(id: Int): Float? = lastMeasured[id]?.widthPx ?: data[id]?.cachedWidth

  /** Main entry point for ShadowNode measurement. */
  fun getMeasureById(
    context: Context,
    id: Int?,
    width: Float,
    widthMode: YogaMeasureMode?,
    height: Float,
    heightMode: YogaMeasureMode?,
    props: ReadableMap?,
    splitTableSegments: Boolean = false,
    // The GFM host's slot children (see BlockSlotMeasureSession); each one is
    // measured where the walk places it.
    blockSlotIds: List<String> = emptyList(),
  ): Long {
    // Early exit for empty markdown. Honor widthMode here too: empty content has
    // zero intrinsic width, so only fill when the width is EXACTLY assigned -
    // otherwise an empty view would claim all available horizontal space.
    val input = measureInput(id, props)
    if (input.markdown.isEmpty()) {
      val emptyWidth = if (widthMode === YogaMeasureMode.EXACTLY) PixelUtil.toDIPFromPixel(width) else 0f
      return YogaMeasureOutput.make(emptyWidth, 0f)
    }

    // The line clamp and break strategy from the props measured, so the first measurement, before
    // the view exists, lays out as the view will. Only the keys sent: the view's own values stay.
    if (id != null) {
      input.config.numberOfLines?.let { numberOfLinesByViewId[id] = it }
      input.config.ellipsizeMode?.let { ellipsizeModeByViewId[id] = it }
      input.config.textBreakStrategy?.let { breakStrategies[id] = it }
    }

    val size = getMeasureByIdInternal(context, id, width, input, splitTableSegments, blockSlotIds)

    // Honor the Yoga width contract. When the parent assigns an exact width
    // (flex child, alignItems: stretch, explicit width / width: "100%"), fill it
    // instead of reporting the content's widest line, which would make the node
    // hug its content and wrap early. Mirrors RN's TextLayoutManager.calculateWidth;
    // iOS already does this via ENRMClampMeasuredSize.
    val resultWidth =
      if (widthMode === YogaMeasureMode.EXACTLY) {
        PixelUtil.toDIPFromPixel(width)
      } else {
        YogaMeasureOutput.getWidth(size)
      }

    var resultHeight = YogaMeasureOutput.getHeight(size)
    if (heightMode === YogaMeasureMode.AT_MOST) {
      resultHeight = resultHeight.coerceAtMost(PixelUtil.toDIPFromPixel(height))
    }

    return YogaMeasureOutput.make(resultWidth, resultHeight)
  }

  fun updateFontScalingSettings(
    viewId: Int,
    allowFontScaling: Boolean,
    maxFontSizeMultiplier: Float,
  ) {
    val previous = fontScalingSettings[viewId]
    fontScalingSettings[viewId] = FontScalingSettings(allowFontScaling, maxFontSizeMultiplier)
    if (previous != null && (previous.allowFontScaling != allowFontScaling || previous.maxFontSizeMultiplier != maxFontSizeMultiplier)) {
      data.remove(viewId)
    }
  }

  fun clearFontScalingSettings(viewId: Int) {
    fontScalingSettings.remove(viewId)
  }

  fun updateBreakStrategy(
    viewId: Int,
    strategy: String,
  ) {
    breakStrategies[viewId] = strategy
  }

  fun clearBreakStrategy(viewId: Int) {
    breakStrategies.remove(viewId)
  }

  private fun resolveBreakStrategy(viewId: Int?): Int = BreakStrategyUtils.resolveBreakStrategy(viewId?.let { breakStrategies[it] })

  fun updateNumberOfLines(
    viewId: Int,
    numberOfLines: Int,
  ) {
    numberOfLinesByViewId[viewId] = numberOfLines
  }

  fun updateEllipsizeMode(
    viewId: Int,
    mode: String,
  ) {
    ellipsizeModeByViewId[viewId] = mode
  }

  private fun resolveMaxLines(viewId: Int?): Int = viewId?.let { numberOfLinesByViewId[it] } ?: 0

  private fun resolveEllipsize(viewId: Int?): TruncateAt? =
    EllipsizeUtils.resolveTruncateAt(viewId?.let { ellipsizeModeByViewId[it] } ?: EllipsizeUtils.DEFAULT_MODE)

  private fun getMeasureByIdInternal(
    context: Context,
    id: Int?,
    width: Float,
    input: MeasureInput,
    splitTableSegments: Boolean,
    blockSlotIds: List<String>,
  ): Long {
    val (allowFontScaling, maxFontSizeMultiplier) = resolveFontScalingSettings(id, input.config)

    val fontScale = checkAndUpdateFontScale(context, allowFontScaling, maxFontSizeMultiplier)

    if (id == null || blockSlotIds.isNotEmpty()) {
      // Slot children are measured where the walk places them; a stream's update takes the view's
      // height when the view shows them where the last walk did (slotStreamUpdate).
      if (id != null) previousInputs.remove(id)
      val streaming = input.config.streaming
      val layoutKey =
        id?.takeIf { streaming }?.let {
          streamLayoutKey(
            it,
            input,
            splitTableSegments,
            allowFontScaling,
            fontScale,
            maxFontSizeMultiplier,
            context.resources.displayMetrics.density,
            context.resources.isLayoutRTL(),
          )
        }
      if (id != null && layoutKey != null) {
        slotStreamUpdate(id, width, input, layoutKey, blockSlotIds)?.let { return it.also { size -> recordMeasured(id, width, size) } }
      }
      val frames = mutableListOf<SlotFrame>()
      // A slot child can hold a document with slots of its own, measured within this walk.
      val outerFrames = recordedFrames.get()
      recordedFrames.set(frames)
      val full =
        try {
          measureInFull(context, id, width, input, splitTableSegments, blockSlotIds, allowFontScaling, fontScale, maxFontSizeMultiplier)
        } finally {
          recordedFrames.set(outerFrames)
        }
      if (id != null && layoutKey != null) {
        val markdown = input.markdown
        val heightPx = PixelUtil.toPixelFromDIP(YogaMeasureOutput.getHeight(full))
        slotMeasurements[id] = SlotMeasured(markdown, layoutKey, blockSlotIds, width, heightPx, full, frames.toList())
      } else if (id != null) {
        slotMeasurements.remove(id)
      }
      return (revealedSize(id, width, input, full) ?: full).also { if (id != null) recordMeasured(id, width, it) }
    }
    slotMeasurements.remove(id)
    laidOutSizeForStreamUpdate(
      id,
      width,
      input,
      splitTableSegments,
      allowFontScaling,
      fontScale,
      maxFontSizeMultiplier,
      context.resources.displayMetrics.density,
      context.resources.isLayoutRTL(),
    )?.let { return it }
    return measureInFull(context, id, width, input, splitTableSegments, blockSlotIds, allowFontScaling, fontScale, maxFontSizeMultiplier)
      .also { recordMeasured(id, width, it) }
  }

  // With smooth pacing the view shows only a start of the markdown, the slots' blocks arriving with
  // the words: the height it laid that start out at. The whole document still places every slot, so a
  // block's space is reserved as soon as it is revealed (the shadow node hides the slots below).
  private fun revealedSize(
    id: Int?,
    width: Float,
    input: MeasureInput,
    full: Long,
  ): Long? = revealedSize(id, width, input, full, id?.let { laidOutSizes[it] })

  private fun revealedSize(
    id: Int?,
    width: Float,
    input: MeasureInput,
    full: Long,
    published: LaidOutSize?,
  ): Long? {
    if (id == null || !input.config.smooth) return null
    val markdown = input.markdown
    val laidOut =
      published?.takeIf {
        it.isFor(width) && it.markdown.length < markdown.length && markdownExtends(it.markdown, markdown)
      } ?: return null
    val height = YogaMeasureOutput.getHeight(laidOut.size)
    return if (height < YogaMeasureOutput.getHeight(full)) YogaMeasureOutput.make(YogaMeasureOutput.getWidth(full), height) else null
  }

  private fun measureInFull(
    context: Context,
    id: Int?,
    width: Float,
    input: MeasureInput,
    splitTableSegments: Boolean,
    blockSlotIds: List<String>,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
  ): Long {
    // Split measurement always goes through the full measure path (no spannable caching)
    if (splitTableSegments) {
      return measureAndCacheSplit(context, id, width, input, allowFontScaling, fontScale, maxFontSizeMultiplier, blockSlotIds)
    }

    val safeId = id ?: return measureAndCache(context, null, width, input, allowFontScaling, fontScale, maxFontSizeMultiplier)
    val cached = data[safeId] ?: return measureAndCache(context, safeId, width, input, allowFontScaling, fontScale, maxFontSizeMultiplier)

    val currentHash = computePropsHash(input, allowFontScaling, fontScale, maxFontSizeMultiplier)

    if (cached.markdownHash != currentHash) {
      return measureAndCache(context, safeId, width, input, allowFontScaling, fontScale, maxFontSizeMultiplier)
    }

    // Width changed - re-measure with cached spannable
    if (cached.cachedWidth != width) {
      val spannable =
        cached.spannable ?: return measureAndCache(context, safeId, width, input, allowFontScaling, fontScale, maxFontSizeMultiplier)
      val newSize = measure(width, spannable, cached.paintParams, safeId)
      data[safeId] = cached.copy(cachedWidth = width, cachedSize = newSize)
      return newSize
    }

    return cached.cachedSize
  }

  // A stream's update: the markdown only grew and nothing else that sizes the content
  // changed. The size the view laid out at is behind by at most the render in flight.
  // Null to measure in full: new content, another width or a view that hasn't laid out.
  internal fun laidOutSizeForStreamUpdate(
    id: Int,
    width: Float,
    input: MeasureInput,
    splitTableSegments: Boolean,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
    density: Float,
    rtl: Boolean,
  ): Long? {
    // Text appended without `streaming` measures in full, so it has its height on the first commit.
    if (!input.config.streaming) {
      previousInputs.remove(id)
      return null
    }
    val markdown = input.markdown
    val layoutKey = streamLayoutKey(id, input, splitTableSegments, allowFontScaling, fontScale, maxFontSizeMultiplier, density, rtl)

    val inputs = MeasuredInputs(markdown, layoutKey, width)
    var earlier: List<MeasuredInputs>? = null
    previousInputs.compute(id) { _, list ->
      earlier = list
      listOf(inputs) + list.orEmpty().filter { it.widthPx != width }.take(1)
    }
    val previous = earlier?.let { list -> list.firstOrNull { it.widthPx == width } ?: list.firstOrNull() } ?: return null
    // The view's size counts for an earlier state of this stream, not a document it replaced.
    val laidOut = laidOutSizes[id]?.takeIf { it.isFor(width) && markdownExtends(it.markdown, markdown) }
    val source =
      chooseMeasurement(
        streamUpdate = previous.layoutKey == layoutKey && markdownExtends(previous.markdown, markdown),
        grew = markdown.length > previous.markdown.length,
        // A laid-out answer can be behind the markdown, so a newer laid-out size replaces it: the
        // view may have laid out an update between two of this stream's (or, with smooth pacing,
        // a further part of it) and asks no more once its height stops changing.
        viewLaidOutAgain =
          laidOut != null &&
            (laidOut.markdown == markdown || ((input.config.smooth || previous.fromLaidOut) && laidOut.size != previous.size)),
        hasLaidOutSize = laidOut != null,
        // An answer the view's size gave stands only while that size does.
        samePreviousWidth = previous.size != null && previous.widthPx == width && (laidOut != null || !previous.fromLaidOut),
      )
    val size =
      when (source) {
        MeasurementSource.LAID_OUT -> laidOut?.size
        MeasurementSource.PREVIOUS -> previous.size
        MeasurementSource.FULL -> null
      } ?: return null
    val fromLaidOut = source == MeasurementSource.LAID_OUT || (source == MeasurementSource.PREVIOUS && previous.fromLaidOut)
    recordMeasured(id, width, size, fromLaidOut)
    return size
  }

  // Everything besides the markdown and the width that lays a streamed document out (StreamLayoutKey).
  private fun streamLayoutKey(
    id: Int,
    input: MeasureInput,
    splitTableSegments: Boolean,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
    density: Float,
    rtl: Boolean,
  ): StreamLayoutKey =
    StreamLayoutKey(
      config = input.config.key,
      fontScale = fontScale,
      allowFontScaling = allowFontScaling,
      maxFontSizeMultiplier = maxFontSizeMultiplier,
      splitTableSegments = splitTableSegments,
      wrappedCodeBlocks = wrappedCodeBlocks[id],
      breakStrategy = breakStrategies[id],
      density = density,
      rtl = rtl,
    )

  // A stream's update on a document with block slots: the view's height when it shows every slot
  // where the last full measurement placed it (SlotLayoutReuse), else null to measure in full.
  private fun slotStreamUpdate(
    id: Int,
    width: Float,
    input: MeasureInput,
    layoutKey: StreamLayoutKey,
    slotIds: List<String>,
  ): Long? {
    if (!input.config.streaming) return null
    val previous = slotMeasurements[id] ?: return null
    val markdown = input.markdown
    if (abs(previous.widthPx - width) >= 1f || previous.layoutKey != layoutKey || previous.slotIds != slotIds ||
      !markdownExtends(previous.markdown, markdown)
    ) {
      return null
    }
    // Every slot was placed by the last walk.
    if (previous.frames.size != slotIds.size) return null
    val laidOut = laidOutSizes[id]?.takeIf { it.isFor(width) && markdownExtends(it.markdown, markdown) } ?: return null
    // A shown slot takes the view's position (SlotLayoutReuse). Measuring a child again records its
    // frame there for the shadow node.
    val shownY = previous.frames.map { frame -> laidOut.slots.firstOrNull { it.id == frame.id }?.y ?: frame.y }
    val measured =
      previous.frames.mapIndexed { i, frame ->
        SlotLayoutReuse.MeasuredSlot(frame.id, frame.y, frame.height, nativeMeasureBlockSlot(frame.id, frame.x, shownY[i], frame.width))
      }
    val laidOutHeight = PixelUtil.toPixelFromDIP(YogaMeasureOutput.getHeight(laidOut.size))
    val smooth = input.config.smooth
    var heightPx = laidOutHeight
    if (!SlotLayoutReuse.canTake(smooth, heightPx, measured, laidOut.slots, SLOT_TOLERANCE_PX)) {
      // A code block streaming into its renderer at the end: only that slot's child grew.
      val endsInsideOpenFence = !smooth && renderableResult(input).endsInsideOpenCodeFence
      heightPx =
        SlotLayoutReuse.growingTailHeight(endsInsideOpenFence, previous.heightPx, laidOutHeight, measured, laidOut.slots, SLOT_TOLERANCE_PX)
      if (heightPx <= 0f) {
        nativeDiscardBlockSlotFrames()
        return null
      }
    }
    val size = YogaMeasureOutput.make(YogaMeasureOutput.getWidth(previous.size), PixelUtil.toDIPFromPixel(heightPx))
    val frames = previous.frames.mapIndexed { i, frame -> frame.copy(y = shownY[i], height = measured[i].childHeight) }
    slotMeasurements[id] = previous.copy(markdown = markdown, heightPx = heightPx, size = size, frames = frames)
    // With smooth pacing, from the same layout the height came from.
    return revealedSize(id, width, input, size, laidOut) ?: size
  }

  internal enum class MeasurementSource { FULL, PREVIOUS, LAID_OUT }

  /**
   * iOS's ENRMChooseMeasurement, without the view's height counter: [viewLaidOutAgain] stands
   * in for the view asking again. A grown document never takes the previous answer: a view
   * sized to its content would keep it for good.
   */
  internal fun chooseMeasurement(
    streamUpdate: Boolean,
    grew: Boolean,
    viewLaidOutAgain: Boolean,
    hasLaidOutSize: Boolean,
    samePreviousWidth: Boolean,
  ): MeasurementSource =
    when {
      !streamUpdate -> MeasurementSource.FULL
      hasLaidOutSize && (grew || viewLaidOutAgain) -> MeasurementSource.LAID_OUT
      !grew && samePreviousWidth -> MeasurementSource.PREVIOUS
      else -> MeasurementSource.FULL
    }

  // Remembers what the measurement of [id] returned, for the next one to compare with.
  internal fun recordMeasured(
    id: Int,
    width: Float,
    size: Long,
    fromLaidOut: Boolean = false,
  ) {
    lastMeasured[id] = Measured(width, size)
    previousInputs.computeIfPresent(
      id,
    ) { _, inputs -> listOf(inputs.first().copy(size = size, fromLaidOut = fromLaidOut)) + inputs.drop(1) }
  }

  /** Whether [current] keeps all of [previous] and only adds to it, as every update of a stream does. */
  internal fun markdownExtends(
    previous: String,
    current: String,
  ): Boolean = previous.isNotEmpty() && current.startsWith(previous)

  private fun computePropsHash(
    input: MeasureInput,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
  ): Int {
    val markdown = renderableMarkdown(input)
    return computePropsHashForMarkdown(markdown, input, allowFontScaling, fontScale, maxFontSizeMultiplier)
  }

  // The markdown as the view renders it: while streaming, the core streaming session's
  // snapshot. The modes come with the layout props (conversions.h), so the first measurement
  // and one after a mode change prepare exactly what the view renders.
  private fun renderableMarkdown(input: MeasureInput): String {
    if (!input.config.streaming) return input.markdown
    return renderableResult(input).markdown
  }

  // The streaming session's snapshot of the markdown.
  private fun renderableResult(input: MeasureInput): StreamingFilterResult =
    StreamingMarkdownFilter.renderableMarkdownForStreaming(
      input.markdown,
      input.config.md4cFlags,
      TableStreamingMode.fromString(input.config.tableMode),
      CodeBlockStreamingMode.fromString(input.config.codeBlockMode),
      MediaStreamingMode.fromString(input.config.mediaMode),
      tables = input.config.isGFM,
    )

  private fun computePropsHashForMarkdown(
    markdown: String,
    input: MeasureInput,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
  ): Int {
    var result = markdown.hashCode()
    result = 31 * result + input.config.key
    result = 31 * result + fontScale.toBits()
    result = 31 * result + allowFontScaling.hashCode()
    result = 31 * result + maxFontSizeMultiplier.toBits()
    return result
  }

  private fun checkAndUpdateFontScale(
    context: Context,
    allowFontScaling: Boolean,
    maxFontSizeMultiplier: Float,
  ): Float {
    if (!allowFontScaling) {
      // Clear cache if we switched from scaling to non-scaling
      if (lastKnownFontScale != 1.0f) {
        lastKnownFontScale = 1.0f
        data.clear()
      }
      return 1.0f
    }

    var currentFontScale = context.resources.configuration.fontScale

    if (maxFontSizeMultiplier >= 1.0f && currentFontScale > maxFontSizeMultiplier) {
      currentFontScale = maxFontSizeMultiplier
    }
    if (currentFontScale != lastKnownFontScale) {
      lastKnownFontScale = currentFontScale
      data.clear()
    }
    return currentFontScale
  }

  private fun measureAndCache(
    context: Context,
    id: Int?,
    width: Float,
    input: MeasureInput,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
  ): Long {
    // 1. Extract Props & Setup
    val config = input.config
    val styleMap = config.markdownStyle
    val md4cFlags = config.md4cFlags
    val markdown = renderableMarkdown(input)
    val isGFM = config.isGFM

    val fontSize = getInitialFontSize(styleMap, context, allowFontScaling, fontScale, maxFontSizeMultiplier)
    val propsHash = computePropsHash(input, allowFontScaling, fontScale, maxFontSizeMultiplier)

    // 2. Render & Measure
    measurePaint.textSize = fontSize
    val linkRecognition = config.linkRecognition
    val spannable =
      tryRenderMarkdown(
        markdown,
        styleMap,
        context,
        md4cFlags,
        isGFM,
        allowFontScaling,
        maxFontSizeMultiplier,
        config.imageRequestHeaders,
        config.linkPillContent,
        linkRecognition.text,
        linkRecognition.inlineCode,
      )
    spannable?.replaceMathSpansWithPlaceholders(context)
    val textToMeasure = spannable ?: markdown
    val (size, _) = measureWithLayout(width, textToMeasure, measurePaint, id)

    // 3. Calculate Margin
    val allowTrailingMargin = config.allowTrailingMargin
    val marginBottom =
      if (allowTrailingMargin && spannable != null) {
        PixelUtil.toDIPFromPixel(measureRenderer.getLastElementMarginBottom())
      } else {
        0f
      }

    // 4. Finalize Height
    val currentWidth = YogaMeasureOutput.getWidth(size)
    val currentHeight = YogaMeasureOutput.getHeight(size)
    val adjustedSize = YogaMeasureOutput.make(currentWidth, currentHeight + marginBottom)

    if (id != null) {
      data[id] = MeasurementParams(width, adjustedSize, textToMeasure, PaintParams(Typeface.DEFAULT, fontSize), propsHash)
    }

    return adjustedSize
  }

  private fun measureAndCacheSplit(
    context: Context,
    id: Int?,
    width: Float,
    input: MeasureInput,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
    blockSlotIds: List<String>,
  ): Long {
    val config = input.config
    val isStreaming = config.streaming
    val md4cFlags = config.md4cFlags
    val markdown = renderableMarkdown(input)
    val wrapped =
      if (config.enableCodeBlockWrapToggle) {
        id?.let { wrappedCodeBlocks[it] } ?: emptySet()
      } else {
        emptySet()
      }
    // A Set's hashCode sums its elements, so {} and {0} would collide; the sorted list's doesn't.
    // Density joins the key: an app that handles density changes itself keeps the view
    // alive while every px measurement below changes. So do the slot ids: a size
    // measured with React children in place must not serve the slot-free document.
    val density = context.resources.displayMetrics.density
    val propsHash =
      31 * (
        31 * (
          31 * computePropsHashForMarkdown(markdown, input, allowFontScaling, fontScale, maxFontSizeMultiplier) +
            wrapped.sorted().hashCode()
        ) + density.hashCode()
      ) + blockSlotIds.hashCode()

    // Streaming shortcut: reuse cached size when the prepared content and
    // width are unchanged. When it changes (e.g. a table becomes complete),
    // the hash differs and we fall through to full measure.
    // Slot children need their frames recorded on every measure, so they never
    // take it.
    if (isStreaming && id != null && blockSlotIds.isEmpty()) {
      val cached = data[id]
      if (cached != null && cached.cachedWidth == width && cached.markdownHash == propsHash) {
        return cached.cachedSize
      }
    }
    val styleMap =
      config.markdownStyle
        ?: return YogaMeasureOutput.make(PixelUtil.toDIPFromPixel(width), 0f)

    val isGFM = config.isGFM
    val allowTrailingMargin = config.allowTrailingMargin
    val fontSize = getInitialFontSize(styleMap, context, allowFontScaling, fontScale, maxFontSizeMultiplier)

    val linkRecognition = config.linkRecognition
    val imageSources = config.imageSources

    return try {
      val ast =
        Parser.shared.parseMarkdown(
          markdown,
          md4cFlags,
          isGFM,
          linkRecognition.text,
          linkRecognition.inlineCode,
          blockSlotIds.toSet(),
          imageSources.isNotEmpty(),
        )
          ?: return YogaMeasureOutput.make(PixelUtil.toDIPFromPixel(width), 0f)

      val style = StyleConfig(styleMap, context, allowFontScaling, maxFontSizeMultiplier)
      style.imageRequestHeaders = config.imageRequestHeaders
      style.imageSourceOverrides = imageSources
      style.linkPillContent = config.linkPillContent
      val segments = splitASTIntoSegments(ast)
      val renderedSegments = MarkdownSegmentRenderer.render(segments, style, context, null, null)

      val mathHeightByIndex = HashMap<Int, Float>()
      val mathSegmentIndices = mutableListOf<Int>()
      val mathRequests = mutableListOf<MathMeasureRequest>()
      for ((i, segment) in renderedSegments.withIndex()) {
        if (segment is RenderedSegment.Math) {
          mathSegmentIndices.add(i)
          mathRequests.add(
            MathMeasureRequest(
              fontSize = style.mathStyle.fontSize,
              latex = segment.latex,
              mode = MathRenderMode.Display,
            ),
          )
        }
      }
      if (mathRequests.isNotEmpty()) {
        val mathResults = measureMathOnMainThread(context, mathRequests)
        for (i in mathSegmentIndices.indices) {
          val metrics = mathResults[i]
          mathHeightByIndex[mathSegmentIndices[i]] =
            ceil(metrics.ascent + metrics.descent).toInt() + (style.mathStyle.padding * 2)
        }
      }

      // One walk for the root stack and for nested quotes (SegmentHeightMeasurer),
      // so measure and render cannot drift between the two.
      val stack =
        SegmentHeightMeasurer.measureRootStack(
          renderedSegments,
          style,
          context,
          width,
          fontSize,
          resolveBreakStrategy(id),
          allowTrailingMargin,
          mathHeightForIndex = { mathHeightByIndex[it] ?: 0f },
          wrapCursor = CodeBlockWrapCursor(wrapped),
          slotMeasurer = slotMeasurer,
        )
      val totalHeightPx = stack.heightPx
      val maxContentWidthPx = stack.maxContentWidthPx

      val totalHeightDip = PixelUtil.toDIPFromPixel(totalHeightPx)
      val measuredWidthDip = PixelUtil.toDIPFromPixel(maxContentWidthPx).coerceAtMost(PixelUtil.toDIPFromPixel(width))
      val result = YogaMeasureOutput.make(measuredWidthDip, totalHeightDip)

      if (id != null) {
        data[id] = MeasurementParams(width, result, null, PaintParams(Typeface.DEFAULT, fontSize), propsHash)
      }
      result
    } catch (e: Exception) {
      // The fallback measures without slots, so every block renders natively.
      slotMeasurer.discard()
      Log.w(TAG, "Split measurement failed, falling back without block renderers", e)
      measureAndCache(context, id, width, input, allowFontScaling, fontScale, maxFontSizeMultiplier)
    }
  }

  private fun createStaticLayout(
    text: CharSequence,
    fontSize: Float,
    widthPx: Int,
    viewId: Int?,
  ): StaticLayout {
    measurePaint.textSize = fontSize
    prepareWidthAwareSpans(text, widthPx)
    return StaticLayout.Builder
      .obtain(text, 0, text.length, measurePaint, widthPx)
      .setIncludePad(false)
      .setLineSpacing(0f, 1f)
      .apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          @Suppress("WrongConstant")
          setBreakStrategy(resolveBreakStrategy(viewId))
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
          setUseLineSpacingFromFallbacks(true)
        }
      }.build()
  }

  private fun tryRenderMarkdown(
    markdown: String,
    styleMap: ReadableMap?,
    context: Context,
    md4cFlags: Md4cFlags,
    isGFM: Boolean,
    allowFontScaling: Boolean,
    maxFontSizeMultiplier: Float,
    imageRequestHeaders: Map<String, String> = emptyMap(),
    linkPillContent: Map<String, LinkPillContent> = emptyMap(),
    linkRegex: LinkRegexConfig? = null,
    inlineCodeLinkRegex: LinkRegexConfig? = null,
  ): Spannable? {
    if (styleMap == null) return null

    return try {
      val ast = Parser.shared.parseMarkdown(markdown, md4cFlags, isGFM, linkRegex, inlineCodeLinkRegex) ?: return null
      val style = StyleConfig(styleMap, context, allowFontScaling, maxFontSizeMultiplier)
      style.imageRequestHeaders = imageRequestHeaders
      style.linkPillContent = linkPillContent
      measureRenderer.configure(style, context)
      measureRenderer.renderDocument(ast, null)
    } catch (e: Exception) {
      Log.w(TAG, "Failed to render markdown for measurement, falling back to raw text", e)
      null
    }
  }

  private fun getInitialFontSize(
    styleMap: ReadableMap?,
    context: Context,
    allowFontScaling: Boolean,
    fontScale: Float,
    maxFontSizeMultiplier: Float,
  ): Float {
    val fontSizeSp = styleMap?.getMap("paragraph")?.getDouble("fontSize")?.toFloat() ?: 16f
    val density = context.resources.displayMetrics.density

    if (!allowFontScaling) {
      return ceil(fontSizeSp * density)
    }

    val cappedFontScale =
      if (maxFontSizeMultiplier >= 1.0f && fontScale > maxFontSizeMultiplier) {
        maxFontSizeMultiplier
      } else {
        fontScale
      }
    return ceil(fontSizeSp * cappedFontScale * density)
  }

  private fun measure(
    maxWidth: Float,
    text: CharSequence?,
    paintParams: PaintParams,
    viewId: Int?,
  ): Long {
    measurePaint.reset()
    measurePaint.isAntiAlias = true
    measurePaint.typeface = paintParams.typeface
    measurePaint.textSize = paintParams.fontSize
    return measure(maxWidth, text, measurePaint, viewId)
  }

  private fun measure(
    maxWidth: Float,
    text: CharSequence?,
    paint: TextPaint,
    viewId: Int?,
  ): Long {
    val content = text ?: ""
    val safeWidth = ceil(maxWidth).toInt().coerceAtLeast(1)
    prepareWidthAwareSpans(content, safeWidth)

    val layout = buildMeasureLayout(content, paint, safeWidth, viewId)
    val visibleLineCount = visibleLineCount(layout, viewId)
    val measuredHeight = truncatedHeight(layout, visibleLineCount, content)

    // Calculate actual content width (widest visible line)
    val measuredWidth = (0 until visibleLineCount).maxOfOrNull { layout.getLineWidth(it) } ?: 0f

    return YogaMeasureOutput.make(
      PixelUtil.toDIPFromPixel(ceil(measuredWidth)),
      PixelUtil.toDIPFromPixel(measuredHeight),
    )
  }

  private fun buildMeasureLayout(
    content: CharSequence,
    paint: TextPaint,
    widthPx: Int,
    viewId: Int?,
  ): StaticLayout {
    val builder =
      StaticLayout.Builder
        .obtain(inViewSpanOrder(content), 0, content.length, paint, widthPx)
        .setIncludePad(false)
        .setLineSpacing(0f, 1f)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      @Suppress("WrongConstant")
      builder.setBreakStrategy(resolveBreakStrategy(viewId))
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      builder.setUseLineSpacingFromFallbacks(true)
    }

    BoundsForWidthUtils.applyTo(builder)
    applyLineLimit(builder, viewId)
    return builder.build()
  }

  // Applies the per-view numberOfLines / ellipsizeMode clamp to a builder, matching
  // RN's TextLayoutManager.buildLayout: only when a line limit is set.
  private fun applyLineLimit(
    builder: StaticLayout.Builder,
    viewId: Int?,
  ) {
    val maxLines = resolveMaxLines(viewId)
    if (maxLines > 0) {
      builder.setMaxLines(maxLines).setEllipsize(resolveEllipsize(viewId))
    }
  }

  private fun visibleLineCount(
    layout: StaticLayout,
    viewId: Int?,
  ): Int {
    val maxLines = resolveMaxLines(viewId)
    return if (maxLines > 0) minOf(maxLines, layout.lineCount) else layout.lineCount
  }

  private fun truncatedHeight(
    layout: StaticLayout,
    visibleLineCount: Int,
    text: CharSequence,
  ): Float {
    if (visibleLineCount <= 0) return 0f
    val lastLine = visibleLineCount - 1
    val bottom = layout.getLineBottom(lastLine).toFloat()
    return (bottom - measureLeakedTrailingMargin(layout, lastLine, text)).coerceAtLeast(0f)
  }

  // When we clamp the text mid-paragraph, drop the trailing block margin that Android
  // bakes into the truncated last line (only when content follows, like MarginBottomSpan).
  private fun measureLeakedTrailingMargin(
    layout: StaticLayout,
    lastLine: Int,
    text: CharSequence,
  ): Float {
    val spanned = text as? Spanned ?: return 0f
    val lineStart = layout.getLineStart(lastLine)
    val lineEnd = layout.getLineEnd(lastLine)
    if (lineEnd <= lineStart || lineEnd < 1 || text[lineEnd - 1] != '\n') return 0f
    if (!hasContentAfter(text, lineEnd)) return 0f
    val trailing =
      spanned
        .getSpans(lineStart, lineEnd, MarginBottomSpan::class.java)
        .firstOrNull { spanned.getSpanEnd(it) == lineEnd } ?: return 0f
    return trailing.marginBottom.toInt().toFloat()
  }

  private fun hasContentAfter(
    text: CharSequence,
    pos: Int,
  ): Boolean {
    if (pos >= text.length) return false
    if (text[pos] == '\n') {
      val nextPos = pos + 1
      if (nextPos >= text.length) return false
      return text[nextPos] != '\n'
    }
    return true
  }

  /**
   * Measures text and returns both the size and the layout for calculating last line descent.
   */
  private fun measureWithLayout(
    maxWidth: Float,
    text: CharSequence?,
    paint: TextPaint,
    viewId: Int?,
  ): Pair<Long, StaticLayout> {
    val content = text ?: ""
    val widthPx = ceil(maxWidth).toInt().coerceAtLeast(1)
    prepareWidthAwareSpans(content, widthPx)

    val layout = buildMeasureLayout(content, paint, widthPx, viewId)

    val visibleLineCount = visibleLineCount(layout, viewId)

    // Find the widest visible line to get the actual content width
    val maxLineWidth =
      (0 until visibleLineCount)
        .maxOfOrNull { layout.getLineWidth(it) } ?: 0f

    val size =
      YogaMeasureOutput.make(
        PixelUtil.toDIPFromPixel(ceil(maxLineWidth)),
        PixelUtil.toDIPFromPixel(truncatedHeight(layout, visibleLineCount, content)),
      )

    return size to layout
  }

  private fun measureMathOnMainThread(
    context: Context,
    requests: List<MathMeasureRequest>,
  ): List<MathMetrics> {
    if (!FeatureFlags.IS_MATH_ENABLED || requests.isEmpty()) {
      return requests.map { estimateMathFallback(it) }
    }
    return try {
      val mathMeasureHelperClass = Class.forName("com.swmansion.enriched.markdown.spans.MathMeasureHelper")
      val method = mathMeasureHelperClass.getMethod("measure", Context::class.java, List::class.java)
      @Suppress("UNCHECKED_CAST")
      method.invoke(null, context, requests) as List<MathMetrics>
    } catch (_: Exception) {
      requests.map { estimateMathFallback(it) }
    }
  }

  private fun estimateMathFallback(request: MathMeasureRequest): MathMetrics {
    val estimatedHeight = request.fontSize * 1.4f
    return MathMetrics(
      width =
        (request.fontSize * request.latex.length * 0.5f)
          .coerceIn(request.fontSize, request.fontSize * 20f)
          .toInt(),
      ascent = estimatedHeight * 0.7f,
      descent = estimatedHeight * 0.3f,
    )
  }
}
