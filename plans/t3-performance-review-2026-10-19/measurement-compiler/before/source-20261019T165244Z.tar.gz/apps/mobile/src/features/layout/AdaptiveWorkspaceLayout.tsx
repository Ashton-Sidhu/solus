// Adapted from T3 Code apps/mobile/src/features/layout/AdaptiveWorkspaceLayout.tsx (MIT, see UPSTREAM.md).
import {
  CommonActions,
  StackActions,
  useNavigation,
} from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";
import {
  createContext,
  use,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Platform, useWindowDimensions, View } from "react-native";
import Animated, {
  useAnimatedStyle,
  useDerivedValue,
  useSharedValue,
  withTiming,
} from "react-native-reanimated";

import {
  deriveFileInspectorPaneLayout,
  deriveLayout,
  deriveWorkspacePaneLayout,
  type FileInspectorPaneLayout,
  type Layout,
  type WorkspaceAuxiliaryPaneRole,
  type WorkspacePaneLayout,
} from "../../lib/layout";
import {
  resolveThreadSelectionNavigationAction,
  resolveThreadSelectionOverlayState,
} from "../../lib/adaptive-navigation";
import type { RootStackParamList } from "../../navigation/routes";
import { useKeyboardCommand } from "../keyboard/use-keyboard-command";
import { AndroidHomeFabLayout } from "../home/AndroidHomeFab";
import { HomeListOptionsProvider } from "../home/home-list-options";
import { threadKey, type SolusThreadShell } from "../threads/thread-directory";
import { ThreadNavigationSidebar } from "../threads/ThreadNavigationSidebar";
import { useThreadListRefresh } from "../threads/use-thread-list";
import { useAgentLiveActivity } from "../live-activity/use-agent-live-activity";
import { RenderErrorBoundary, RenderFailureView } from "../../components/RenderErrorBoundary";
import { WORKSPACE_PANE_TIMING } from "./workspace-pane-animation";
import { WorkspaceInspectorPane } from "./workspace-inspector-pane";
import { WorkspaceContentWidthContext } from "./workspace-content-width";
import { NativeWorkspaceModeContext } from "../../native/v5-workspace-context";

/**
 * Where the workspace is: the topmost root route that is not a sheet over it.
 * Solus reads route names and params where T3 reads a URL path.
 */
export interface WorkspaceLocation {
  readonly routeName: keyof RootStackParamList | undefined;
  readonly routeKey: string | undefined;
  /** The thread the workspace shows, when it shows one. */
  readonly thread: RootStackParamList["Thread"] | null;
}

interface AdaptiveWorkspaceContextValue {
  readonly layout: Layout;
  readonly panes: WorkspacePaneLayout;
  readonly fileInspector: FileInspectorPaneLayout;
  readonly primarySidebarSearchQuery: string;
  readonly selectThread: (thread: SolusThreadShell) => void;
  readonly activateAuxiliaryPaneRole: (role: WorkspaceAuxiliaryPaneRole) => () => void;
  /**
   * Route screens hand their inspector pane content to the workspace so it
   * renders BESIDE the navigator (outside the native stack header) instead of
   * inside the route. Returns a deactivate callback: the pane animates closed
   * (content kept mounted for the exit transition) unless a newer
   * registration already took over — stale deactivates never clobber it.
   * Prefer useRegisterWorkspaceInspector over calling this directly.
   */
  readonly registerWorkspaceInspector: (render: () => ReactNode) => () => void;
  readonly setPrimarySidebarSearchQuery: (query: string) => void;
  readonly showAuxiliaryPane: (role: WorkspaceAuxiliaryPaneRole) => void;
  readonly toggleAuxiliaryPane: () => void;
  readonly togglePrimarySidebar: () => void;
  readonly setAuxiliaryPaneWidth: (width: number) => void;
}

const compactLayout = deriveLayout({ width: 0, height: 0 });
const compactPanes = deriveWorkspacePaneLayout({
  layout: compactLayout,
  viewportWidth: 0,
  primarySidebarPreferredVisible: true,
  auxiliaryPanePreferredVisible: true,
});
const compactFileInspector = deriveFileInspectorPaneLayout({
  layout: compactLayout,
  viewportWidth: 0,
});
const AdaptiveWorkspaceContext = createContext<AdaptiveWorkspaceContextValue>({
  layout: compactLayout,
  panes: compactPanes,
  fileInspector: compactFileInspector,
  primarySidebarSearchQuery: "",
  selectThread: () => undefined,
  activateAuxiliaryPaneRole: () => () => undefined,
  registerWorkspaceInspector: () => () => undefined,
  setPrimarySidebarSearchQuery: () => undefined,
  showAuxiliaryPane: () => undefined,
  toggleAuxiliaryPane: () => undefined,
  togglePrimarySidebar: () => undefined,
  setAuxiliaryPaneWidth: () => undefined,
});

export function useAdaptiveWorkspaceLayout(): AdaptiveWorkspaceContextValue {
  return use(AdaptiveWorkspaceContext);
}

/** File routes own the inspector role; T3 matches a `/files` path. */
function isFileRoute(routeName: WorkspaceLocation["routeName"]): boolean {
  return routeName === "Files" || routeName === "File";
}

export function AdaptiveWorkspaceLayout(props: {
  readonly children: ReactNode;
  readonly location: WorkspaceLocation;
}) {
  const nativeWorkspace = use(NativeWorkspaceModeContext);
  const { width, height } = useWindowDimensions();
  const routeName = props.location.routeName;
  const isHome = routeName === "Home";
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  // One reader keeps every host's thread list current for Home and the sidebar.
  useThreadListRefresh();
  useAgentLiveActivity();
  const activeRoleOwner = useRef<symbol | null>(null);
  const [primarySidebarPreferredVisible, setPrimarySidebarPreferredVisible] = useState(true);
  const showPrimarySidebar = isHome || primarySidebarPreferredVisible;
  const [supplementaryPanePreferredVisible, setSupplementaryPanePreferredVisible] = useState(true);
  const [supplementaryPanePreferredWidth, setSupplementaryPanePreferredWidth] = useState<
    number | null
  >(null);
  const [fileInspectorPreferredVisible, setFileInspectorPreferredVisible] = useState(true);
  const [fileInspectorPreferredWidth, setFileInspectorPreferredWidth] = useState<number | null>(
    null,
  );
  const [primarySidebarSearchQuery, setPrimarySidebarSearchQuery] = useState("");
  const [focusedAuxiliaryPaneRole, setFocusedAuxiliaryPaneRole] =
    useState<WorkspaceAuxiliaryPaneRole | null>(null);
  const baseLayout = useMemo(() => deriveLayout({ width, height }), [height, width]);
  const layout = baseLayout;
  // In split layouts the sidebar IS the thread list — it renders on every
  // route, including Home (which shows an empty-detail pane instead of the
  // compact list).
  const shouldRenderPrimarySidebar = layout.usesSplitView;
  const fileInspector = useMemo(
    () =>
      deriveFileInspectorPaneLayout({
        layout,
        viewportWidth: width,
        preferredWidth: fileInspectorPreferredWidth ?? undefined,
        reservedLeadingWidth:
          shouldRenderPrimarySidebar && showPrimarySidebar ? (layout.listPaneWidth ?? 0) : 0,
      }),
    [fileInspectorPreferredWidth, layout, showPrimarySidebar, shouldRenderPrimarySidebar, width],
  );
  const auxiliaryPaneRole: WorkspaceAuxiliaryPaneRole =
    focusedAuxiliaryPaneRole ?? (isFileRoute(routeName) ? "inspector" : "supplementary");
  const auxiliaryPanePreferredVisible =
    auxiliaryPaneRole === "inspector"
      ? fileInspectorPreferredVisible
      : supplementaryPanePreferredVisible;
  const auxiliaryPanePreferredWidth =
    auxiliaryPaneRole === "inspector"
      ? fileInspectorPreferredWidth
      : supplementaryPanePreferredWidth;
  const panes = useMemo(
    () =>
      deriveWorkspacePaneLayout({
        layout,
        viewportWidth: width,
        primarySidebarPreferredVisible: showPrimarySidebar,
        auxiliaryPanePreferredVisible,
        auxiliaryPaneRole,
        auxiliaryPanePreferredWidth: auxiliaryPanePreferredWidth ?? undefined,
      }),
    [
      auxiliaryPanePreferredVisible,
      auxiliaryPaneRole,
      auxiliaryPanePreferredWidth,
      layout,
      showPrimarySidebar,
      width,
    ],
  );
  const activeThread = props.location.thread;
  const selectedThreadKey =
    activeThread === null ? null : threadKey(activeThread.hostId, activeThread.sessionId);
  // Wrapped in an object: bare functions in useState would be treated as
  // lazy initializers/updaters. `active: false` keeps the outgoing route's
  // content mounted so the pane can animate closed (or be replaced
  // seamlessly by the next route's registration in the same commit).
  const [workspaceInspector, setWorkspaceInspector] = useState<{
    readonly render: () => ReactNode;
    readonly active: boolean;
  } | null>(null);
  const workspaceInspectorOwner = useRef<symbol | null>(null);
  const registerWorkspaceInspector = useCallback((render: () => ReactNode) => {
    const owner = Symbol("workspace-inspector");
    workspaceInspectorOwner.current = owner;
    setWorkspaceInspector({ render, active: true });

    return () => {
      // During a push/replace the outgoing screen deactivates AFTER the
      // incoming screen registered — only the current owner may deactivate.
      if (workspaceInspectorOwner.current !== owner) {
        return;
      }
      setWorkspaceInspector((current) => (current === null ? null : { ...current, active: false }));
    };
  }, []);
  // Once the close animation settles, drop the stale content entirely.
  const handleWorkspaceInspectorClosed = useCallback(() => {
    setWorkspaceInspector((current) => (current !== null && !current.active ? null : current));
  }, []);
  const activateAuxiliaryPaneRole = useCallback((role: WorkspaceAuxiliaryPaneRole) => {
    const owner = Symbol(role);
    activeRoleOwner.current = owner;
    setFocusedAuxiliaryPaneRole(role);

    return () => {
      if (activeRoleOwner.current !== owner) {
        return;
      }
      activeRoleOwner.current = null;
      setFocusedAuxiliaryPaneRole(null);
    };
  }, []);
  const togglePrimarySidebar = useCallback(() => {
    if (isHome) {
      return;
    }
    if (!panes.primarySidebarVisible && panes.primarySidebarSuppressedByAuxiliary) {
      setFileInspectorPreferredVisible(false);
      setPrimarySidebarPreferredVisible(true);
      return;
    }
    setPrimarySidebarPreferredVisible((current) => !current);
  }, [isHome, panes.primarySidebarSuppressedByAuxiliary, panes.primarySidebarVisible]);
  const revealPrimarySidebar = useCallback(() => {
    if (panes.primarySidebarSuppressedByAuxiliary) {
      setFileInspectorPreferredVisible(false);
    }
    setPrimarySidebarPreferredVisible(true);
  }, [panes.primarySidebarSuppressedByAuxiliary]);
  // ⌘B, Solus's sidebar command, toggles the sidebar off Home.
  useKeyboardCommand("toggleSidebar", togglePrimarySidebar, layout.usesSplitView && !isHome);
  const showAuxiliaryPane = useCallback((role: WorkspaceAuxiliaryPaneRole) => {
    if (role === "inspector") {
      setFocusedAuxiliaryPaneRole("inspector");
      setFileInspectorPreferredVisible(true);
      return;
    }
    setFocusedAuxiliaryPaneRole("supplementary");
    setSupplementaryPanePreferredVisible(true);
  }, []);
  const toggleAuxiliaryPane = useCallback(() => {
    if (auxiliaryPaneRole === "inspector") {
      setFileInspectorPreferredVisible((current) => !current);
      return;
    }
    setSupplementaryPanePreferredVisible((current) => !current);
  }, [auxiliaryPaneRole]);
  const setAuxiliaryPaneWidth = useCallback(
    (nextWidth: number) => {
      if (auxiliaryPaneRole === "inspector") {
        setFileInspectorPreferredWidth(nextWidth);
        return;
      }
      setSupplementaryPanePreferredWidth(nextWidth);
    },
    [auxiliaryPaneRole],
  );
  const handleOpenSettings = useCallback(() => {
    navigation.navigate("Settings");
  }, [navigation]);

  const handleStartNewTask = useCallback(() => {
    navigation.navigate("NewTask");
  }, [navigation]);

  // Minted here (root stack navigation) so the sidebar pane stays free of
  // navigation hooks — on iOS it renders inside an independent nav tree.
  // Solus keeps its hosts on their own screen; T3 opens environment settings.
  const handleOpenEnvironmentSettings = useCallback(() => {
    navigation.navigate("Hosts");
  }, [navigation]);

  const renderedSidebarWidth = useSharedValue(
    panes.primarySidebarVisible ? (layout.listPaneWidth ?? 0) : 0,
  );
  useEffect(() => {
    if (nativeWorkspace) return;
    const targetWidth = panes.primarySidebarVisible ? (layout.listPaneWidth ?? 0) : 0;
    renderedSidebarWidth.value = withTiming(targetWidth, WORKSPACE_PANE_TIMING);
  }, [nativeWorkspace, layout.listPaneWidth, panes.primarySidebarVisible, renderedSidebarWidth]);
  const sidebarAnimatedStyle = useAnimatedStyle(() => ({
    opacity: Math.min(1, renderedSidebarWidth.value / 80),
    width: renderedSidebarWidth.value,
  }));

  // Freeze the content pane at its SETTLED width while the side panes
  // animate. The navigator (native header + markdown feed) lays out ONCE per
  // pane toggle instead of re-measuring on every animation frame — the
  // animating columns merely clip/reveal it over a matching background.
  // Continuously re-wrapping the chat feed was the main source of dropped
  // frames during sidebar/inspector transitions.
  const inspectorColumnTargetWidth =
    workspaceInspector !== null && workspaceInspector.active && panes.auxiliaryPaneVisible
      ? (panes.auxiliaryPaneWidth ?? 0)
      : 0;
  const contentSettledWidth = layout.usesSplitView
    ? Math.max(0, panes.contentPaneWidth - inspectorColumnTargetWidth)
    : null;
  const renderedInspectorWidth = useSharedValue(inspectorColumnTargetWidth);
  const renderedContentWidth = useDerivedValue(() =>
    Math.max(0, width - renderedSidebarWidth.value - renderedInspectorWidth.value),
  );

  const handleSelectThread = useCallback(
    (thread: SolusThreadShell) => {
      const params: RootStackParamList["Thread"] = {
        hostId: thread.hostId,
        sessionId: thread.record.sessionId,
      };
      const navigationAction = resolveThreadSelectionNavigationAction({
        usesSplitView: layout.usesSplitView,
        routeName,
      });
      const overlayState = resolveThreadSelectionOverlayState({
        state: navigation.getState(),
        workspaceRouteKey: props.location.routeKey,
        action: navigationAction,
        params,
      });
      if (overlayState !== null) {
        setFileInspectorPreferredVisible(false);
        navigation.dispatch(CommonActions.reset(overlayState));
        return;
      }
      if (navigationAction === "set-params") {
        if (thread.key === selectedThreadKey) {
          return;
        }
        setFileInspectorPreferredVisible(false);
        navigation.navigate("Thread", params);
        return;
      }
      if (navigationAction === "replace") {
        setFileInspectorPreferredVisible(false);
        navigation.dispatch(StackActions.replace("Thread", params));
        return;
      }
      navigation.navigate("Thread", params);
    },
    [layout.usesSplitView, routeName, navigation, selectedThreadKey, props.location.routeKey],
  );

  const contextValue = useMemo(
    () => ({
      layout,
      panes,
      fileInspector,
      primarySidebarSearchQuery,
      selectThread: handleSelectThread,
      activateAuxiliaryPaneRole,
      registerWorkspaceInspector,
      setPrimarySidebarSearchQuery,
      showAuxiliaryPane,
      toggleAuxiliaryPane,
      togglePrimarySidebar,
      setAuxiliaryPaneWidth,
    }),
    [
      activateAuxiliaryPaneRole,
      fileInspector,
      handleSelectThread,
      layout,
      panes,
      primarySidebarSearchQuery,
      registerWorkspaceInspector,
      showAuxiliaryPane,
      setPrimarySidebarSearchQuery,
      setAuxiliaryPaneWidth,
      toggleAuxiliaryPane,
      togglePrimarySidebar,
    ],
  );

  // iPad columns: UIKit draws the sidebar and the detail (createWorkspaceStackNavigator.ios.tsx).
  if (nativeWorkspace) {
    return (
      <HomeListOptionsProvider>
        <AdaptiveWorkspaceContext.Provider value={contextValue}>
          {props.children}
        </AdaptiveWorkspaceContext.Provider>
      </HomeListOptionsProvider>
    );
  }
  return (
    <HomeListOptionsProvider>
      <AdaptiveWorkspaceContext.Provider value={contextValue}>
        <View testID="adaptive-workspace-layout" className="flex-1 flex-row">
          {shouldRenderPrimarySidebar && layout.listPaneWidth !== null ? (
            <Animated.View
              className="self-stretch overflow-hidden"
              accessibilityElementsHidden={!panes.primarySidebarVisible}
              collapsable={false}
              importantForAccessibility={
                panes.primarySidebarVisible ? "auto" : "no-hide-descendants"
              }
              pointerEvents={panes.primarySidebarVisible ? "auto" : "none"}
              style={sidebarAnimatedStyle}
            >
              <View className="flex-1" style={{ width: layout.listPaneWidth }}>
                <RenderErrorBoundary
                  renderFallback={(fallback) => (
                    <RenderFailureView
                      {...fallback}
                      title="The sidebar couldn't be displayed"
                      exit={{ label: "Open settings", onPress: handleOpenSettings }}
                    />
                  )}
                >
                  <AndroidHomeFabLayout sidebar onStartNewTask={handleStartNewTask}>
                    <ThreadNavigationSidebar
                      width={layout.listPaneWidth}
                      visible={panes.primarySidebarVisible}
                      onRequestVisibility={revealPrimarySidebar}
                      selectedThreadKey={selectedThreadKey}
                      onOpenSettings={handleOpenSettings}
                      onOpenEnvironmentSettings={handleOpenEnvironmentSettings}
                      onSelectThread={handleSelectThread}
                      onSearchQueryChange={setPrimarySidebarSearchQuery}
                      searchQuery={primarySidebarSearchQuery}
                    />
                  </AndroidHomeFabLayout>
                </RenderErrorBoundary>
              </View>
            </Animated.View>
          ) : null}
          <View
            className={
              Platform.OS === "android"
                ? "flex-1 overflow-hidden bg-header"
                : "flex-1 overflow-hidden bg-screen"
            }
            collapsable={false}
          >
            <View
              collapsable={false}
              style={
                contentSettledWidth !== null
                  ? {
                      flex: 1,
                      width: contentSettledWidth,
                    }
                  : { flex: 1 }
              }
            >
              <WorkspaceContentWidthContext
                value={layout.usesSplitView ? renderedContentWidth : null}
              >
                {props.children}
              </WorkspaceContentWidthContext>
            </View>
          </View>
          <WorkspaceInspectorPane
            pathname={`${routeName ?? ""}:${props.location.routeKey ?? ""}`}
            renderedInspectorWidth={renderedInspectorWidth}
            active={workspaceInspector?.active ?? false}
            panes={panes}
            renderInspector={workspaceInspector?.render}
            setAuxiliaryPaneWidth={setAuxiliaryPaneWidth}
            onClosed={handleWorkspaceInspectorClosed}
          />
        </View>
      </AdaptiveWorkspaceContext.Provider>
    </HomeListOptionsProvider>
  );
}
