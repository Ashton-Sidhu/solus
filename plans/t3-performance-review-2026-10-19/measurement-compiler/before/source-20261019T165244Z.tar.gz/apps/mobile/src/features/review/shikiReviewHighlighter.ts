// Adapted from T3 Code apps/mobile/src/features/review/shikiReviewHighlighter.ts (MIT, see UPSTREAM.md).
// Only the snippet and source-file highlighting; no review diffs.
import { createHighlighterCore, type GrammarState, type HighlighterCore } from "@shikijs/core";
import { createJavaScriptRegexEngine } from "@shikijs/engine-javascript";
import bashLanguage from "@shikijs/langs/bash";
import javascriptLanguage from "@shikijs/langs/javascript";
import jsonLanguage from "@shikijs/langs/json";
import jsxLanguage from "@shikijs/langs/jsx";
import tsxLanguage from "@shikijs/langs/tsx";
import typescriptLanguage from "@shikijs/langs/typescript";
import yamlLanguage from "@shikijs/langs/yaml";
import githubDarkDefault from "@shikijs/themes/github-dark-default";
import githubLightDefault from "@shikijs/themes/github-light-default";

import {
  resolveReviewHighlighterEngine,
  resolveReviewHighlighterEnginePreference,
} from "./reviewHighlighterEngine";
import { createIncrementalSnippet } from "./incrementalSnippet";

export type ReviewDiffTheme = "light" | "dark";

type ReviewHighlighterEngineName = "native" | "javascript";

export class ReviewHighlighterEngineInitializationError extends Error {
  readonly preferredEngine: ReviewHighlighterEngineName;
  readonly attemptedEngine: ReviewHighlighterEngineName;

  constructor(input: {
    readonly preferredEngine: ReviewHighlighterEngineName;
    readonly attemptedEngine: ReviewHighlighterEngineName;
    readonly cause: unknown;
  }) {
    super(
      `Failed to initialize the ${input.attemptedEngine} review highlighter with ${input.preferredEngine} preferred.`,
      { cause: input.cause },
    );
    this.name = "ReviewHighlighterEngineInitializationError";
    this.preferredEngine = input.preferredEngine;
    this.attemptedEngine = input.attemptedEngine;
  }
}

/**
 * Replaces `@pierre/diffs`'s file-type lookup: the extension, or a known file
 * name, which `resolveLanguageAlias` then maps to a Shiki language.
 */
const FILETYPE_BY_NAME = new Map<string, string>([
  [".bash_profile", "bash"],
  [".bashrc", "bash"],
  [".zprofile", "bash"],
  [".zshrc", "bash"],
  ["cmakelists.txt", "cmake"],
  ["containerfile", "docker"],
  ["dockerfile", "docker"],
  ["gemfile", "ruby"],
  ["gnumakefile", "makefile"],
  ["makefile", "makefile"],
  ["podfile", "ruby"],
  ["rakefile", "ruby"],
]);

const FILETYPE_BY_EXTENSION = new Map<string, string>([
  ["cc", "cpp"],
  ["cxx", "cpp"],
  ["gql", "graphql"],
  ["gradle", "groovy"],
  ["h", "c"],
  ["hh", "cpp"],
  ["hpp", "cpp"],
  ["htm", "html"],
  ["hxx", "cpp"],
  ["kt", "kotlin"],
  ["kts", "kotlin"],
  ["m", "objective-c"],
  ["mk", "makefile"],
  ["mm", "objective-c"],
  ["patch", "diff"],
  ["pl", "perl"],
  ["pm", "perl"],
]);

function getFiletypeFromFileName(path: string): string | null {
  const separatorIndex = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
  const basename = path.slice(separatorIndex + 1).toLowerCase();
  const byName = FILETYPE_BY_NAME.get(basename);
  if (byName) return byName;
  const dotIndex = basename.lastIndexOf(".");
  if (dotIndex < 0 || dotIndex === basename.length - 1) return null;
  const extension = basename.slice(dotIndex + 1);
  return FILETYPE_BY_EXTENSION.get(extension) ?? extension;
}

import type { ReviewHighlightedToken } from "./reviewHighlightedToken.types";

export type { ReviewHighlightedToken } from "./reviewHighlightedToken.types";

const SHIKI_THEME_NAME_BY_SCHEME = {
  light: "github-light-default",
  dark: "github-dark-default",
} as const;
const REVIEW_HIGHLIGHTER_ENGINE_ENV_VALUE =
  process.env.EXPO_PUBLIC_REVIEW_HIGHLIGHTER_ENGINE ??
  (process.env.NODE_ENV === "test" ? "javascript" : "native");
const REVIEW_HIGHLIGHTER_ENGINE_PREFERENCE = resolveReviewHighlighterEnginePreference(
  REVIEW_HIGHLIGHTER_ENGINE_ENV_VALUE,
);
const REVIEW_HIGHLIGHT_CHUNK_LINE_THRESHOLD = 8;
// Bounds each tokenizing call by characters, not lines, so a file of long
// lines still yields to touches and renders between short batches.
const REVIEW_HIGHLIGHT_CHUNK_CHARACTERS = 2_000;
// A yield waits a timer turn, so batches run back to back until about one
// frame of work has passed instead of yielding after every batch.
const REVIEW_HIGHLIGHT_YIELD_AFTER_MS = 16;
const REVIEW_TOKENIZE_MAX_LINE_LENGTH = 1_000;
const REVIEW_INITIAL_LANGUAGE_MODULES = [
  bashLanguage,
  javascriptLanguage,
  jsonLanguage,
  jsxLanguage,
  tsxLanguage,
  typescriptLanguage,
  yamlLanguage,
] satisfies Parameters<typeof createHighlighterCore>[0]["langs"];
const loadedLanguages = new Set<string>([
  "text",
  "bash",
  "javascript",
  "json",
  "jsx",
  "tsx",
  "typescript",
  "yaml",
]);
const languageLoadingPromises = new Map<string, Promise<boolean>>();
const languageImports: Partial<Record<string, () => Promise<unknown>>> = {
  javascript: () => import("@shikijs/langs/javascript"),
  typescript: () => import("@shikijs/langs/typescript"),
  jsx: () => import("@shikijs/langs/jsx"),
  tsx: () => import("@shikijs/langs/tsx"),
  python: () => import("@shikijs/langs/python"),
  rust: () => import("@shikijs/langs/rust"),
  go: () => import("@shikijs/langs/go"),
  java: () => import("@shikijs/langs/java"),
  kotlin: () => import("@shikijs/langs/kotlin"),
  swift: () => import("@shikijs/langs/swift"),
  "objective-c": () => import("@shikijs/langs/objective-c"),
  c: () => import("@shikijs/langs/c"),
  cpp: () => import("@shikijs/langs/cpp"),
  csharp: () => import("@shikijs/langs/csharp"),
  php: () => import("@shikijs/langs/php"),
  ruby: () => import("@shikijs/langs/ruby"),
  lua: () => import("@shikijs/langs/lua"),
  perl: () => import("@shikijs/langs/perl"),
  r: () => import("@shikijs/langs/r"),
  dart: () => import("@shikijs/langs/dart"),
  scala: () => import("@shikijs/langs/scala"),
  elixir: () => import("@shikijs/langs/elixir"),
  haskell: () => import("@shikijs/langs/haskell"),
  clojure: () => import("@shikijs/langs/clojure"),
  ocaml: () => import("@shikijs/langs/ocaml"),
  fsharp: () => import("@shikijs/langs/fsharp"),
  erlang: () => import("@shikijs/langs/erlang"),
  zig: () => import("@shikijs/langs/zig"),
  nim: () => import("@shikijs/langs/nim"),
  html: () => import("@shikijs/langs/html"),
  css: () => import("@shikijs/langs/css"),
  scss: () => import("@shikijs/langs/scss"),
  less: () => import("@shikijs/langs/less"),
  xml: () => import("@shikijs/langs/xml"),
  svg: () => import("@shikijs/langs/xml"),
  vue: () => import("@shikijs/langs/vue"),
  svelte: () => import("@shikijs/langs/svelte"),
  astro: () => import("@shikijs/langs/astro"),
  json: () => import("@shikijs/langs/json"),
  jsonc: () => import("@shikijs/langs/jsonc"),
  yaml: () => import("@shikijs/langs/yaml"),
  toml: () => import("@shikijs/langs/toml"),
  ini: () => import("@shikijs/langs/ini"),
  bash: () => import("@shikijs/langs/bash"),
  shellscript: () => import("@shikijs/langs/shellscript"),
  powershell: () => import("@shikijs/langs/powershell"),
  fish: () => import("@shikijs/langs/fish"),
  sql: () => import("@shikijs/langs/sql"),
  graphql: () => import("@shikijs/langs/graphql"),
  prisma: () => import("@shikijs/langs/prisma"),
  docker: () => import("@shikijs/langs/docker"),
  hcl: () => import("@shikijs/langs/hcl"),
  nix: () => import("@shikijs/langs/nix"),
  markdown: () => import("@shikijs/langs/markdown"),
  mdx: () => import("@shikijs/langs/mdx"),
  tex: () => import("@shikijs/langs/tex"),
  diff: () => import("@shikijs/langs/diff"),
  regex: () => import("@shikijs/langs/regex"),
  viml: () => import("@shikijs/langs/viml"),
  makefile: () => import("@shikijs/langs/makefile"),
  cmake: () => import("@shikijs/langs/cmake"),
  groovy: () => import("@shikijs/langs/groovy"),
};

const languageAliases: Record<string, string> = {
  js: "javascript",
  mjs: "javascript",
  cjs: "javascript",
  ts: "typescript",
  mts: "typescript",
  cts: "typescript",
  py: "python",
  rb: "ruby",
  rs: "rust",
  sh: "bash",
  zsh: "bash",
  shell: "shellscript",
  yml: "yaml",
  md: "markdown",
  "c++": "cpp",
  "c#": "csharp",
  cs: "csharp",
  dockerfile: "docker",
  vim: "viml",
  objc: "objective-c",
  objectivec: "objective-c",
  "obj-c": "objective-c",
  ps1: "powershell",
  pwsh: "powershell",
  hs: "haskell",
  ex: "elixir",
  exs: "elixir",
  erl: "erlang",
  clj: "clojure",
  ml: "ocaml",
  fs: "fsharp",
  tf: "hcl",
  make: "makefile",
  plain: "text",
  plaintext: "text",
  txt: "text",
};
let highlighterPromise: Promise<HighlighterCore> | null = null;

type LoadedLanguageModule = {
  default: Parameters<HighlighterCore["loadLanguage"]>[0];
};

function isReviewHighlighterDebugLoggingEnabled(): boolean {
  return typeof __DEV__ !== "undefined" ? __DEV__ : false;
}

interface ReviewHighlighterDiagnosticDetails {
  readonly configuredPreference?: string;
  readonly preference?: string;
  readonly nativeEngineAvailable?: boolean;
  readonly reason?: string;
  readonly resolvedEngine?: string;
}

function logReviewHighlighterDiagnostic(
  message: string,
  details?: ReviewHighlighterDiagnosticDetails,
): void {
  if (!isReviewHighlighterDebugLoggingEnabled()) {
    return;
  }

  if (details) {
    console.log(`[review-highlighter] ${message}`, details);
    return;
  }

  console.log(`[review-highlighter] ${message}`);
}

function logReviewHighlighterDiagnosticError(message: string, error: unknown): void {
  if (!isReviewHighlighterDebugLoggingEnabled()) {
    return;
  }
  console.error(`[review-highlighter] ${message}`, error);
}

function waitForNextFrame(): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, 0);
  });
}

async function getHighlighter(): Promise<HighlighterCore> {
  if (!highlighterPromise) {
    const configuredHighlighterPromise = (async () => {
      let nativeEngineAvailable = false;
      let nativeInitializationError: ReviewHighlighterEngineInitializationError | undefined;

      logReviewHighlighterDiagnostic("initializing", {
        configuredPreference: REVIEW_HIGHLIGHTER_ENGINE_ENV_VALUE,
        preference: REVIEW_HIGHLIGHTER_ENGINE_PREFERENCE,
      });

      const themes = [githubLightDefault, githubDarkDefault];

      if (REVIEW_HIGHLIGHTER_ENGINE_PREFERENCE !== "javascript") {
        try {
          const nativeEngineModule = await import("react-native-shiki-engine");
          nativeEngineAvailable = nativeEngineModule.isNativeEngineAvailable();
          logReviewHighlighterDiagnostic("checked native engine availability", {
            nativeEngineAvailable,
          });

          if (nativeEngineAvailable) {
            logReviewHighlighterDiagnostic("creating native regex engine");
            const highlighter = await createHighlighterCore({
              themes,
              langs: REVIEW_INITIAL_LANGUAGE_MODULES,
              engine: nativeEngineModule.createNativeEngine(),
            });
            logReviewHighlighterDiagnostic("using native engine");
            return highlighter;
          }
        } catch (error) {
          nativeInitializationError = new ReviewHighlighterEngineInitializationError({
            preferredEngine: REVIEW_HIGHLIGHTER_ENGINE_PREFERENCE,
            attemptedEngine: "native",
            cause: error,
          });
          logReviewHighlighterDiagnosticError(
            "native engine initialization failed; falling back to javascript",
            nativeInitializationError,
          );
          nativeEngineAvailable = false;
        }
      } else {
        logReviewHighlighterDiagnostic("skipping native engine probe", {
          reason: "preference-forced-javascript",
        });
      }

      const engine = resolveReviewHighlighterEngine(
        REVIEW_HIGHLIGHTER_ENGINE_PREFERENCE,
        nativeEngineAvailable,
      );
      let highlighter: HighlighterCore;
      try {
        highlighter = await createHighlighterCore({
          themes,
          langs: REVIEW_INITIAL_LANGUAGE_MODULES,
          engine: createJavaScriptRegexEngine(),
        });
      } catch (cause) {
        const javascriptError = new ReviewHighlighterEngineInitializationError({
          preferredEngine: REVIEW_HIGHLIGHTER_ENGINE_PREFERENCE,
          attemptedEngine: "javascript",
          cause,
        });
        if (!nativeInitializationError) throw javascriptError;
        throw new ReviewHighlighterEngineInitializationError({
          preferredEngine: REVIEW_HIGHLIGHTER_ENGINE_PREFERENCE,
          attemptedEngine: "javascript",
          cause: new AggregateError(
            [nativeInitializationError, javascriptError],
            "Native and JavaScript review highlighter initialization failed.",
            { cause: nativeInitializationError },
          ),
        });
      }
      logReviewHighlighterDiagnostic("using javascript engine", {
        resolvedEngine: engine,
      });
      return highlighter;
    })();

    highlighterPromise = configuredHighlighterPromise.catch((error) => {
      highlighterPromise = null;
      throw error;
    });
  }

  return highlighterPromise;
}

function resolveLanguageAlias(language: string): string {
  const normalized = language.toLowerCase();
  return languageAliases[normalized] ?? normalized;
}

function resolveLoadedLanguageFromPath(
  path: string,
  languageHint: string | null = null,
): string | null {
  const detectedLanguage = languageHint ?? getFiletypeFromFileName(path);
  if (!detectedLanguage) {
    return "text";
  }

  const candidate = resolveLanguageAlias(detectedLanguage);
  if (candidate === "text" || candidate === "ansi") {
    return "text";
  }

  if (!(candidate in languageImports)) {
    return "text";
  }

  return loadedLanguages.has(candidate) ? candidate : null;
}

async function loadSingleLanguage(
  highlighter: HighlighterCore,
  language: string,
): Promise<boolean> {
  if (loadedLanguages.has(language)) {
    return true;
  }

  const existingPromise = languageLoadingPromises.get(language);
  if (existingPromise) {
    return existingPromise;
  }

  const importer = languageImports[language];
  if (!importer) {
    return false;
  }

  const loadingPromise = (async () => {
    try {
      const languageModule = (await importer()) as LoadedLanguageModule;
      await highlighter.loadLanguage(languageModule.default);
      loadedLanguages.add(language);
      return true;
    } catch {
      return false;
    } finally {
      languageLoadingPromises.delete(language);
    }
  })();

  languageLoadingPromises.set(language, loadingPromise);
  return loadingPromise;
}

async function resolveLanguageFromPath(
  path: string,
  languageHint: string | null = null,
): Promise<string> {
  const loadedLanguage = resolveLoadedLanguageFromPath(path, languageHint);
  if (loadedLanguage) {
    return loadedLanguage;
  }

  const detectedLanguage = languageHint ?? getFiletypeFromFileName(path);
  if (!detectedLanguage) {
    return "text";
  }

  const candidate = resolveLanguageAlias(detectedLanguage);
  if (candidate === "text" || candidate === "ansi") {
    return "text";
  }

  if (!(candidate in languageImports)) {
    return "text";
  }

  if (loadedLanguages.has(candidate)) {
    return candidate;
  }

  const highlighter = await getHighlighter();
  const loaded = await loadSingleLanguage(highlighter, candidate);
  if (!loaded) {
    return "text";
  }

  return candidate;
}

type RawHighlightedLine = ReadonlyArray<{ content: string; color?: string; fontStyle?: number }>;
const normalizedLines = new WeakMap<RawHighlightedLine, ReadonlyArray<ReviewHighlightedToken>>();

function normalizeHighlightedLines(
  tokenLines: ReadonlyArray<RawHighlightedLine>,
): ReadonlyArray<ReadonlyArray<ReviewHighlightedToken>> {
  return tokenLines.map((line) => {
    const cached = normalizedLines.get(line);
    if (cached) return cached;
    const normalized = line.map((token) => ({
      content: token.content,
      color: token.color ?? null,
      fontStyle: token.fontStyle ?? null,
    }));
    normalizedLines.set(line, normalized);
    return normalized;
  });
}

async function highlightLines(
  code: string,
  language: string,
  theme: string,
): Promise<ReadonlyArray<ReadonlyArray<ReviewHighlightedToken>>> {
  if (code.length === 0) {
    return [];
  }

  const highlighter = await getHighlighter();
  const sourceLines = code.split("\n");
  const highlightedLines: Array<ReadonlyArray<ReviewHighlightedToken>> = [];
  // Each batch resumes from the previous batch's grammar state, so a comment
  // or template string that spans a batch boundary keeps its colors.
  let grammarState: GrammarState | undefined;
  let start = 0;
  let sliceStartedAt = performance.now();

  while (start < sourceLines.length) {
    if (sourceLines[start]!.length > REVIEW_TOKENIZE_MAX_LINE_LENGTH) {
      highlightedLines.push([{ content: sourceLines[start]!, color: null, fontStyle: null }]);
      // A skipped line's ending state is unknown; the next batch starts fresh.
      grammarState = undefined;
      start += 1;
    } else {
      let end = start;
      let characters = 0;
      while (end < sourceLines.length) {
        const length = sourceLines[end]!.length;
        if (
          length > REVIEW_TOKENIZE_MAX_LINE_LENGTH ||
          (end > start && characters + length + 1 > REVIEW_HIGHLIGHT_CHUNK_CHARACTERS)
        ) {
          break;
        }
        characters += length + (end > start ? 1 : 0);
        end += 1;
      }
      const tokenLines = highlighter.codeToTokensBase(sourceLines.slice(start, end).join("\n"), {
        lang: language,
        theme,
        grammarState,
      });
      grammarState = highlighter.getLastGrammarState(tokenLines);
      highlightedLines.push(...normalizeHighlightedLines(tokenLines));
      start = end;
    }

    if (
      sourceLines.length > REVIEW_HIGHLIGHT_CHUNK_LINE_THRESHOLD &&
      start < sourceLines.length &&
      performance.now() - sliceStartedAt >= REVIEW_HIGHLIGHT_YIELD_AFTER_MS
    ) {
      await waitForNextFrame();
      sliceStartedAt = performance.now();
    }
  }

  return highlightedLines;
}

const snippetSessions = new WeakMap<
  object,
  { language: string; theme: string; highlight: ReturnType<typeof createIncrementalSnippet> }
>();

export async function highlightCodeSnippet(input: {
  readonly session?: object;
  readonly code: string;
  readonly language?: string | null;
  readonly theme: ReviewDiffTheme;
}): Promise<ReadonlyArray<ReadonlyArray<ReviewHighlightedToken>>> {
  const languageHint = input.language?.trim() || "text";
  const language = await resolveLanguageFromPath(`snippet.${languageHint}`, languageHint);
  const theme = SHIKI_THEME_NAME_BY_SCHEME[input.theme];
  // Bound retained text and preserve the existing plain-text/long-line fallback.
  if (
    !input.session ||
    language === "text" ||
    input.code.length === 0 ||
    input.code.length > 100_000 ||
    input.code.includes("\r") ||
    input.code.split("\n").some((line) => line.length > REVIEW_TOKENIZE_MAX_LINE_LENGTH)
  ) {
    if (input.session) snippetSessions.delete(input.session);
    return highlightLines(input.code, language, theme);
  }
  const highlighter = await getHighlighter();
  let session = snippetSessions.get(input.session);
  if (!session || session.language !== language || session.theme !== theme) {
    session = {
      language,
      theme,
      highlight: createIncrementalSnippet(highlighter, language, theme),
    };
    snippetSessions.set(input.session, session);
  }
  return normalizeHighlightedLines(await session.highlight(input.code));
}

highlightCodeSnippet.read = (input: Parameters<typeof highlightCodeSnippet>[0]) => {
  if (!input.session || !input.code || input.code.length > 100_000 || input.code.includes("\r"))
    return undefined;
  const session = snippetSessions.get(input.session);
  const hint = input.language?.trim() || "text";
  const language = resolveLoadedLanguageFromPath(`snippet.${hint}`, hint);
  if (
    !session ||
    session.language !== language ||
    session.theme !== SHIKI_THEME_NAME_BY_SCHEME[input.theme] ||
    input.code.split("\n").some((line) => line.length > REVIEW_TOKENIZE_MAX_LINE_LENGTH)
  )
    return undefined;
  const tokens = session.highlight.read(input.code);
  return tokens ? normalizeHighlightedLines(tokens) : undefined;
};

export async function highlightSourceFile(input: {
  readonly path: string;
  readonly contents: string;
  readonly theme: ReviewDiffTheme;
}): Promise<ReadonlyArray<ReadonlyArray<ReviewHighlightedToken>>> {
  const language = await resolveLanguageFromPath(input.path);
  return highlightLines(input.contents, language, SHIKI_THEME_NAME_BY_SCHEME[input.theme]);
}
