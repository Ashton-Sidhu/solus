// Adapted from T3 Code apps/mobile/src/native/createV5StackNavigator.ios.tsx (MIT, see UPSTREAM.md).
import {
  createNavigatorFactory,
  NavigationContext,
  NavigationRouteContext,
  StackRouter,
  useNavigationBuilder,
  usePreventRemoveContext,
  type NavigatorTypeBagBase,
  type ParamListBase,
  type StackActionHelpers,
  type StackNavigationState,
  type StackRouterOptions,
  type StaticConfig,
  type TypedNavigator,
} from "@react-navigation/native";
import {
  NativeStackView,
  type NativeStackNavigationEventMap,
  type NativeStackNavigationOptions,
  type NativeStackNavigatorProps,
  type NativeStackTypeBag,
} from "@react-navigation/native-stack";
import { useCallback, useRef, useState, type ComponentProps } from "react";
import { View } from "react-native";
import { Stack } from "react-native-screens";

import { NativeColumnContent } from "./NativeColumnContent.ios";
import { NativeScrollEdgeEffectsContext } from "./NativeScrollViewMarker";
import { V5StackHeader } from "./V5StackHeader.ios";
import {
  nativeStackPopAction,
  partitionStackPresentations,
  reconcileStackScreens,
} from "./workspace-stack-projection";

export type V5StackViewProps = ComponentProps<typeof NativeStackView>;

/** Any presentation other than a card opens a new native presentation. */
export function isModalPresentation(options: NativeStackNavigationOptions | undefined): boolean {
  return options?.presentation !== undefined && options.presentation !== "card";
}

/** The presentation envelope must not mount a second search bar or header. */
export function modalEnvelopeOptions(options: NativeStackNavigationOptions) {
  return {
    ...Object.fromEntries(
      Object.entries(options).filter(
        ([key]) =>
          !key.startsWith("header") &&
          !key.startsWith("unstable_header") &&
          key !== "unstable_navigationItemStyle",
      ),
    ),
    headerShown: false,
  };
}

/** Keep outgoing screens until UIKit completes its pop, as required by v5. */
export function V5CardStackView(
  props: V5StackViewProps & { readonly onRootVisibilityChange?: (visible: boolean) => void },
) {
  const { preventedRoutes } = usePreventRemoveContext();
  const nativePopSource = useRef<string | null>(null);
  const [screens, setScreens] = useState({
    completedNativeDismissals: new Set<string>(),
    nativeCompletingPops: new Set<string>(),
    routes: props.state.routes,
    descriptors: props.descriptors,
    observedRoutes: props.state.routes,
    observedDescriptors: props.descriptors,
  });
  if (
    screens.observedRoutes !== props.state.routes ||
    screens.observedDescriptors !== props.descriptors
  ) {
    const routes = reconcileStackScreens(
      screens.routes,
      props.state.routes,
      screens.completedNativeDismissals,
    );
    const active = new Set(props.state.routes.map((route) => route.key));
    const retainedKeys = new Set(routes.map((route) => route.key));
    setScreens({
      nativeCompletingPops: new Set(
        [...screens.nativeCompletingPops].filter((key) => retainedKeys.has(key)),
      ),
      completedNativeDismissals: new Set(
        [...screens.completedNativeDismissals].filter((key) => active.has(key)),
      ),
      routes,
      descriptors: Object.fromEntries(
        Object.entries({ ...screens.descriptors, ...props.descriptors }).filter(([key]) =>
          retainedKeys.has(key),
        ),
      ),
      observedRoutes: props.state.routes,
      observedDescriptors: props.descriptors,
    });
  }
  // Keep the real descriptor through dismissal. describe(route, true) creates
  // a placeholder whose navigation rejects setOptions and dispatches.
  const nativeDismiss = useCallback(
    (key: string) => {
      const state = props.navigation.getState();
      const attached = state.routes.some((route) => route.key === key);
      setScreens((current) => {
        const completedNativeDismissals = new Set(current.completedNativeDismissals);
        const nativeCompletingPops = new Set(current.nativeCompletingPops);
        nativeCompletingPops.delete(key);
        if (attached) {
          completedNativeDismissals.add(key);
          return { ...current, completedNativeDismissals, nativeCompletingPops };
        }
        // A delayed callback needs immediate cleanup: the router already
        // removed the route, so no further router update will follow.
        completedNativeDismissals.delete(key);
        const descriptors = { ...current.descriptors };
        delete descriptors[key];
        return {
          ...current,
          completedNativeDismissals,
          nativeCompletingPops,
          routes: current.routes.filter((route) => route.key !== key),
          descriptors,
        };
      });
      if (nativePopSource.current === key) nativePopSource.current = null;
      const action = nativeStackPopAction(state, key);
      if (action) props.navigation.dispatch(action);
    },
    [props.navigation, setScreens],
  );
  const removeDismissed = useCallback(
    (key: string) => {
      if (!props.navigation.getState().routes.some((route) => route.key === key)) {
        setScreens((current) => {
          const descriptors = { ...current.descriptors };
          delete descriptors[key];
          return {
            ...current,
            routes: current.routes.filter((route) => route.key !== key),
            descriptors,
          };
        });
      }
    },
    [props.navigation, setScreens],
  );
  return (
    <View className="flex-1 bg-screen">
      <Stack.Host>
        {screens.routes.map((route, index) => {
          const descriptor = props.descriptors[route.key] ?? screens.descriptors[route.key];
          if (!descriptor) return null;
          const attached = props.state.routes.some((current) => current.key === route.key);
          return (
            <Stack.Screen
              key={route.key}
              screenKey={route.key}
              activityMode={
                attached || screens.nativeCompletingPops.has(route.key) ? "attached" : "detached"
              }
              preventNativeDismiss={
                preventedRoutes[route.key]?.preventRemove ||
                descriptor.options.gestureEnabled === false
              }
              onDismiss={removeDismissed}
              onNativeDismiss={nativeDismiss}
              onNativeDismissPrevented={() => {
                if (preventedRoutes[route.key]?.preventRemove) descriptor.navigation.goBack();
              }}
              onWillAppear={() => {
                if (index === 0) props.onRootVisibilityChange?.(true);
                props.navigation.emit({
                  type: "transitionStart",
                  target: route.key,
                  data: { closing: false },
                });
              }}
              onDidAppear={() => {
                const source = nativePopSource.current;
                if (source === route.key) {
                  // A cancelled swipe restores its source without changing router history.
                  nativePopSource.current = null;
                } else if (source) {
                  const state = props.navigation.getState();
                  const action = nativeStackPopAction(state, source, route.key);
                  if (action) {
                    const sourceIndex = state.routes.findIndex((current) => current.key === source);
                    // UIKit owns this pop. Keep these children attached until its
                    // dismissal callback, so the early router update cannot enqueue a second pop.
                    const poppedKeys = state.routes
                      .slice(sourceIndex - action.payload.count + 1, sourceIndex + 1)
                      .map((popped) => popped.key);
                    setScreens((current) => ({
                      ...current,
                      nativeCompletingPops: new Set([
                        ...current.nativeCompletingPops,
                        ...poppedKeys,
                      ]),
                    }));
                    nativePopSource.current = null;
                    props.navigation.dispatch(action);
                  }
                }
                props.navigation.emit({
                  type: "transitionEnd",
                  target: route.key,
                  data: { closing: false },
                });
              }}
              onWillDisappear={() => {
                if (index === 0) props.onRootVisibilityChange?.(false);
                const state = props.navigation.getState();
                // JS pushes/pops already changed history. Only native Back leaves
                // the disappearing card at the router's active index.
                if (state.index > 0 && state.routes[state.index]?.key === route.key) {
                  nativePopSource.current = route.key;
                }
                props.navigation.emit({
                  type: "transitionStart",
                  target: route.key,
                  data: { closing: true },
                });
              }}
              onDidDisappear={() =>
                props.navigation.emit({
                  type: "transitionEnd",
                  target: route.key,
                  data: { closing: true },
                })
              }
            >
              <NavigationContext value={descriptor.navigation}>
                <NavigationRouteContext value={descriptor.route}>
                  <V5StackHeader
                    options={descriptor.options}
                    canGoBack={
                      attached
                        ? props.state.routes.findIndex((current) => current.key === route.key) > 0
                        : index > 0
                    }
                  />
                  <NativeColumnContent>
                    <NativeScrollEdgeEffectsContext value={descriptor.options.scrollEdgeEffects}>
                      {descriptor.render()}
                    </NativeScrollEdgeEffectsContext>
                  </NativeColumnContent>
                </NavigationRouteContext>
              </NavigationContext>
            </Stack.Screen>
          );
        })}
      </Stack.Host>
    </View>
  );
}

/** Present each modal group with the legacy renderer; v5 owns the pushes and headers inside it. */
export function V5StackView(props: V5StackViewProps) {
  const groups = partitionStackPresentations(props.state.routes, (route) =>
    isModalPresentation(props.descriptors[route.key]?.options),
  );
  const routes = groups.map((group) => group[0]!);
  const descriptors = Object.fromEntries(
    groups.map((group) => {
      const first = group[0]!;
      const descriptor = props.descriptors[first.key]!;
      const visibleRoute = group.at(-1)!;
      return [
        first.key,
        {
          ...descriptor,
          navigation: props.descriptors[visibleRoute.key]!.navigation,
          // Focus belongs to the pushed page inside this presentation group.
          route: visibleRoute,
          options: modalEnvelopeOptions(descriptor.options),
          render: () => (
            <V5CardStackView
              {...props}
              state={{
                ...props.state,
                routes: group,
                index: group.length - 1,
                preloadedRoutes: [],
              }}
            />
          ),
        },
      ];
    }),
  );
  return (
    <NativeStackView
      presentationEnvelope
      {...props}
      descriptors={descriptors}
      state={{ ...props.state, routes, index: routes.length - 1, preloadedRoutes: [] }}
    />
  );
}

function V5StackNavigator({
  id,
  initialRouteName,
  UNSTABLE_routeNamesChangeBehavior,
  children,
  layout,
  screenListeners,
  screenOptions,
  screenLayout,
  UNSTABLE_router,
  ...rest
}: NativeStackNavigatorProps) {
  const { state, describe, descriptors, navigation, NavigationContent } = useNavigationBuilder<
    StackNavigationState<ParamListBase>,
    StackRouterOptions,
    StackActionHelpers<ParamListBase>,
    NativeStackNavigationOptions,
    NativeStackNavigationEventMap
  >(StackRouter, {
    id,
    initialRouteName,
    UNSTABLE_routeNamesChangeBehavior,
    children,
    layout,
    screenListeners,
    screenOptions,
    screenLayout,
    UNSTABLE_router,
  });
  return (
    <NavigationContent>
      <V5StackView
        {...rest}
        state={state}
        describe={describe}
        descriptors={descriptors}
        navigation={navigation}
      />
    </NavigationContent>
  );
}

type V5TypeBag<ParamList extends ParamListBase, NavigatorID extends string | undefined> = Omit<
  NativeStackTypeBag<ParamList, NavigatorID>,
  "Navigator"
> & { Navigator: typeof V5StackNavigator };

export function createV5StackNavigator<
  const ParamList extends ParamListBase,
  const NavigatorID extends string | undefined = string | undefined,
  const TypeBag extends NavigatorTypeBagBase = V5TypeBag<ParamList, NavigatorID>,
  const Config extends StaticConfig<TypeBag> = StaticConfig<TypeBag>,
>(config?: Config): TypedNavigator<TypeBag, Config> {
  return createNavigatorFactory(V5StackNavigator)(config);
}
